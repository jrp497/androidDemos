package com.example.testdemo;

import java.util.ArrayList;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class ThirdActivity extends Activity {
	private Button button;
	private int mYear;
	private int month;
	private int day;
	private ProgressBar progressbar;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_third);
		final AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView) findViewById(R.id.autocompletetextview);
		final SeekBar seekbar = (SeekBar) findViewById(R.id.seekbar);
		button = (Button) findViewById(R.id.button);
		final WebView webView = (WebView) findViewById(R.id.webview);
		progressbar = (ProgressBar) findViewById(R.id.progressbar);
		webView.getSettings().setJavaScriptEnabled(true);
		webView.loadUrl("https://www.youtube.com/");
		webView.setWebViewClient(new MyWebViewClient());

		// final Spinner spinner = (Spinner) findViewById(R.id.spinner);
		//

		final ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("ILDC");
		arrayList.add("ILDC1");
		arrayList.add("ILDC2"); //
		final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, arrayList);
		autoCompleteTextView.setAdapter(adapter);

		seekbar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				Log.e("TAG", "onStopTrackingTouch" + seekBar.getProgress());

			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				Log.e("TAG", "onStartTrackingTouch" + seekBar.getProgress());

			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				Log.e("TAG", "onProgressChanged" + progress);

			}
		});

		final Calendar calendar = Calendar.getInstance();
		mYear = calendar.get(Calendar.YEAR);
		month = calendar.get(Calendar.MONTH);
		day = calendar.get(Calendar.DAY_OF_MONTH);

		// button.setOnClickListener(new OnClickListener() {
		//
		// @Override
		// public void onClick(View v) {
		// DatePickerDialog datePickerDialog = new DatePickerDialog(
		// ThirdActivity.this, onDateSetListener, mYear, month,
		// day);
		// datePickerDialog.show();
		// }
		// });

		button.setOnClickListener(onClickListener);

		//
		// spinner.setAdapter(adapter);

		// final ArrayList<NewTestModel> newTestModelsArrayList = new
		// ArrayList<NewTestModel>();
		//
		// for (int i = 0; i < 10; i++) {
		// final NewTestModel testNewTestModel = new NewTestModel();
		// testNewTestModel.setId("" + i);
		// testNewTestModel.setName("ILDC" + i);
		// testNewTestModel.setAddress("Devarc Mall" + i);
		// newTestModelsArrayList.add(testNewTestModel);
		// }
		//
		// for (int i = 0; i < newTestModelsArrayList.size(); i++) {
		// Log.e("TAG", newTestModelsArrayList.get(i).getId());
		// Log.e("TAG", newTestModelsArrayList.get(i).getName());
		// Log.e("TAG", newTestModelsArrayList.get(i).getAddress());
		// }

	}

	// private class MyWebViewClient extends WebViewClient {
	// @Override
	// public boolean shouldOverrideUrlLoading(WebView view, String url) {
	// view.loadUrl(url);
	// return true;
	// }
	//
	// @Override
	// public void onPageFinished(WebView view, String url) {
	// progressbar.setVisibility(View.GONE);
	// super.onPageFinished(view, url);
	// }
	//
	// @Override
	// public void onPageStarted(WebView view, String url, Bitmap favicon) {
	// progressbar.setVisibility(View.VISIBLE);
	// super.onPageStarted(view, url, favicon);
	// }
	// }

	private class MyWebViewClient extends WebViewClient {

		// @Override
		// public boolean shouldOverrideUrlLoading(WebView view, String url) {
		// view.loadUrl(url);
		// return true;
		// }

		@Override
		public void onPageFinished(WebView view, String url) {
			progressbar.setVisibility(View.GONE);
			super.onPageFinished(view, url);
		}

		@Override
		public void onPageStarted(WebView view, String url, Bitmap favicon) {
			progressbar.setVisibility(View.VISIBLE);
			super.onPageStarted(view, url, favicon);
		}

	}

	OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			month = monthOfYear;
			day = dayOfMonth;
			button.setText(day + "-" + (month + 1) + "-" + mYear);
		}
	};

	OnClickListener onClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			DatePickerDialog datePickerDialog = new DatePickerDialog(
					ThirdActivity.this, onDateSetListener, mYear, month, day);
			datePickerDialog.show();
		}
	};

}
