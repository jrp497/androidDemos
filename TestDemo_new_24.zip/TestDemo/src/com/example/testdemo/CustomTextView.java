package com.example.testdemo;

import android.content.Context;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.TextView;

public class CustomTextView extends TextView {

	public CustomTextView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		Log.e("Tag", "AttributeSet with style");
	}

	public CustomTextView(Context context, AttributeSet attrs) {
		super(context, attrs);
		Log.e("Tag", "AttributeSet");
	}

	public CustomTextView(Context context) {
		super(context);
		Log.e("Tag", "context");
	}

	@Override
	public void setTypeface(Typeface tf) {
		Typeface typeface = Typeface.createFromAsset(
				getResources().getAssets(), "COMICATE.TTF");
		super.setTypeface(typeface);
	}

}
