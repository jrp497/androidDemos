package com.example.testdemo;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;

public class Utils {

	public static void displayDialog(final Context context, final String message) {
		final AlertDialog.Builder builder = new AlertDialog.Builder(context);
		builder.setTitle(context.getString(R.string.app_name));
		builder.setMessage(message);
		builder.setCancelable(false);
		builder.setNegativeButton("Yes", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				dialog.dismiss();
			}
		});
		builder.show();
	}

	
	
	
}
