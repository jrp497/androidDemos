package com.example.testdemo;

import java.util.ArrayList;
import java.util.Calendar;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class ThirdActivity extends Activity {
	private Button button;
	private int mYear;
	private int month;
	private int day;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_third);
		final AutoCompleteTextView autoCompleteTextView = (AutoCompleteTextView) findViewById(R.id.autocompletetextview);
		final SeekBar seekbar = (SeekBar) findViewById(R.id.seekbar);
		button = (Button) findViewById(R.id.button);

		// final Spinner spinner = (Spinner) findViewById(R.id.spinner);
		//
		final ArrayList<String> arrayList = new ArrayList<String>();
		arrayList.add("ILDC");
		arrayList.add("ILDC1");
		arrayList.add("ILDC2"); //
		final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_list_item_1, arrayList);
		autoCompleteTextView.setAdapter(adapter);

		seekbar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				Log.e("TAG", "onStopTrackingTouch" + seekBar.getProgress());

			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				Log.e("TAG", "onStartTrackingTouch" + seekBar.getProgress());

			}

			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				Log.e("TAG", "onProgressChanged" + progress);

			}
		});

		final Calendar calendar = Calendar.getInstance();
		mYear = calendar.get(Calendar.YEAR);
		month = calendar.get(Calendar.MONTH);
		day = calendar.get(Calendar.DAY_OF_MONTH);

		// button.setOnClickListener(new OnClickListener() {
		//
		// @Override
		// public void onClick(View v) {
		// DatePickerDialog datePickerDialog = new DatePickerDialog(
		// ThirdActivity.this, onDateSetListener, mYear, month,
		// day);
		// datePickerDialog.show();
		// }
		// });

		button.setOnClickListener(onClickListener);

		//
		// spinner.setAdapter(adapter);

		// final ArrayList<NewTestModel> newTestModelsArrayList = new
		// ArrayList<NewTestModel>();
		//
		// for (int i = 0; i < 10; i++) {
		// final NewTestModel testNewTestModel = new NewTestModel();
		// testNewTestModel.setId("" + i);
		// testNewTestModel.setName("ILDC" + i);
		// testNewTestModel.setAddress("Devarc Mall" + i);
		// newTestModelsArrayList.add(testNewTestModel);
		// }
		//
		// for (int i = 0; i < newTestModelsArrayList.size(); i++) {
		// Log.e("TAG", newTestModelsArrayList.get(i).getId());
		// Log.e("TAG", newTestModelsArrayList.get(i).getName());
		// Log.e("TAG", newTestModelsArrayList.get(i).getAddress());
		// }

	}

	OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener() {

		@Override
		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			mYear = year;
			month = monthOfYear;
			day = dayOfMonth;
			button.setText(day + "-" + (month + 1) + "-" + mYear);
		}
	};

	OnClickListener onClickListener = new OnClickListener() {

		@Override
		public void onClick(View v) {
			// TODO Auto-generated method stub
			DatePickerDialog datePickerDialog = new DatePickerDialog(
					ThirdActivity.this, onDateSetListener, mYear, month, day);
			datePickerDialog.show();
		}
	};

}
