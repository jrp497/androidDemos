package com.example.indianic.jsondemo;

/**
 * Created by indianic on 21/07/15.
 */
import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.graphics.AvoidXfermode;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomArrayAdapter extends ArrayAdapter<Model> {

    private LayoutInflater layoutInflater;
    private ArrayList<Model> arrayList;

    public CustomArrayAdapter(Context context, int resource,
                              ArrayList<Model> arrayList) {
        super(context, resource, arrayList);
        layoutInflater = ((Activity) context).getLayoutInflater();
        this.arrayList = arrayList;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = layoutInflater.inflate(R.layout.listdialogview, null);
            holder.TVName = (TextView) convertView
                    .findViewById(R.id.textViewName);
            holder.TVID = (TextView) convertView
                    .findViewById(R.id.textViewId);
            holder.TVEmail = (TextView) convertView
                    .findViewById(R.id.textViewEmail);
            holder.TVPhone = (TextView) convertView
                    .findViewById(R.id.textViewPhone);


            convertView.setTag(holder);

        } else {
            holder = (ViewHolder) convertView.getTag();
        }

        final Model listModel = arrayList.get(position);
        holder.TVID.setText(listModel.getId());
        holder.TVName.setText(listModel.getName());
        holder.TVEmail.setText(listModel.getEmail());
        holder.TVPhone.setText(listModel.getPhone());

        return convertView;
    }

    private class ViewHolder {
        private TextView TVID;
        private TextView TVName;
        private TextView TVEmail;
        private TextView TVPhone;
    }

}

