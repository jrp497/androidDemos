package com.example.indianic.retrofitdemo;

import com.google.gson.Gson;

import org.json.JSONException;

import java.net.ConnectException;
import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;

public class RestError {

	private boolean success;
	private String message;
	private int status;

	public RestError(String strMessage) {
		this.message = strMessage;
	}

	public boolean getSuccess() {
		return success;
	}

	public void setSuccess(boolean success) {
		this.success = success;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public abstract static class RetrofitCallback<T> implements Callback<T> {

        public abstract void success(T arg0, RestError restError);

        public abstract void failure(RestError restError);

        @Override
        public void failure(RetrofitError error) {
            final RestError restError = (RestError) error.getBodyAs(RestError.class);
            if (restError != null) {
                // final String json = new String(((TypedByteArray) error.getResponse().getBody()).getBytes());
                // final Gson gson = new Gson();
                // restError = gson.fromJson(json, RestError.class);
                // if (restError != null) {
                if (restError.getStatus() == 401) {
                    restError.setMessage("It appears the account doesn\'t exist. Please sign up! OR You either supplied the wrong credentials (e.g. a bad password)");
                } else if (restError.getStatus() == 409) {
                    restError.setMessage("Email is already registered");
                }
                // }
                // Utils.e("json " + json);
                failure(restError);
            } else {
                if (error.getCause() instanceof SocketTimeoutException) {
                    failure(new RestError("Connection Timeout"));
                } else if (error.getCause() instanceof UnknownHostException || error.getCause() instanceof ConnectException) {
                    failure(new RestError("No Internet Connection Available"));
                } else if (error.getCause() instanceof JSONException) {
                    failure(new RestError("Unable to parse response from server"));
                } else {
                    failure(new RestError("Problem while fetching data from server.Please try again later."));
                }
            }
        }

        @Override
        public void success(T arg0, Response arg1) {
            final Gson gson = new Gson();
            final RestError restError = gson.fromJson(Utils.getStringFromResponse(arg1), RestError.class);
            success(arg0, restError);
        }

    }
}
