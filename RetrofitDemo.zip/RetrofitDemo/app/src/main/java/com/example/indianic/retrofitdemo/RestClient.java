package com.example.indianic.retrofitdemo;

import android.app.Application;
import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.squareup.okhttp.OkHttpClient;

import retrofit.RestAdapter;
import retrofit.client.Client;
import retrofit.client.OkClient;
import retrofit.converter.GsonConverter;

public class RestClient {

    private static final String BASE_URL = "https://api.github.com";
    private WebServicesInterface apiService;
    private static RestClient instance;

    public RestClient(Context context) {
        instance = this;
        final Gson gson = new GsonBuilder().registerTypeAdapterFactory(new ItemTypeAdapterFactory()).setDateFormat("yyyy'-'MM'-'dd'T'HH':'mm':'ss'.'SSS'Z'").create();
        // final int cacheSize = 10 * 1024 * 1024; // 10 MiB
        // final File cacheDirectory = new File(context.getCacheDir().getAbsolutePath(), "HttpCache");
        final OkHttpClient okHttpClient = new OkHttpClient();
        // Cache cache;
        // try {
        // cache = new Cache(cacheDirectory, cacheSize);
        // client.setCache(cache);
        // } catch (IOException e) {
        // e.printStackTrace();
        // }

//		final CookieManager cookieManager = new CookieManager(new PersistentCookieStore(context), CookiePolicy.ACCEPT_ALL);
//		final OkHttpClient okHttpClient = new OkHttpClient();
//		okHttpClient.setCookieHandler(cookieManager);
        final Client client = new OkClient(okHttpClient);

        final RestAdapter restAdapter = new RestAdapter.Builder().setClient(client).setLogLevel(RestAdapter.LogLevel.FULL).setConverter(new GsonConverter(gson)).setEndpoint(BASE_URL).build();

//		final RestAdapter restAdapter = new RestAdapter.Builder().setClient(client).setLogLevel(RestAdapter.LogLevel.FULL).setRequestInterceptor(new RequestInterceptor() {
//
//			@Override
//			public void intercept(RequestInterceptor.RequestFacade requestFacade) {
//				requestFacade.addHeader("", "");
//				requestFacade.addHeader("", "");
//			}
//		}).setConverter(new GsonConverter(gson)).setEndpoint(BASE_URL).build();

        apiService = restAdapter.create(WebServicesInterface.class);
    }

    public WebServicesInterface getApiService() {
        return apiService;
    }

    public static RestClient getInstance() {
        return instance;
    }

//    public static class PlumPerfectApplication extends Application {
//
//        private static PlumPerfectApplication mInstance;
//        // private VolleyHelper mVolleyHelper;
//
//
//        @Override
//        public void onCreate() {
//            super.onCreate();
//            mInstance = this;
//
//            new RestClient(mInstance);
//
//        }
//
//        public void onTerminate() {
//            super.onTerminate();
//            // if (mVolleyHelper != null) {
//            // mVolleyHelper.cancelPendingRequests();
//            // mVolleyHelper = null;
//            // }
//            if (mInstance != null) {
//                mInstance = null;
//            }
//
//
//        }
//
//
//    }
}
