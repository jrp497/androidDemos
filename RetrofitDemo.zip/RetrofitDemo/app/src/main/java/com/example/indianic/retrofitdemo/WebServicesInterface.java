/*
 * Copyright (c) 2014.
 * Ahesanali Khanusiya
 */

package com.example.indianic.retrofitdemo;


import retrofit.Callback;
import retrofit.client.Response;
import retrofit.http.Field;
import retrofit.http.GET;
import retrofit.http.Path;

/**
 * Created by Ahesan Khanusiya on 8/4/2014.
 */
public interface WebServicesInterface {

    @GET("/users/{user}")
    public void getFeed(@Path("user") String user, RestError.RetrofitCallback<Response> response);

//	@POST("/v2/user/profiles/from-upload")
//	@Multipart
//	Response uploadPhoto(@Part("profile_type_id") String email, @Part("image") TypedFile file);
//
//	// @POST("/v2/user/profiles/from-upload")
//	// @Multipart
//	// void uploadPhoto(@Part("profile_type_id") String email, @Part("image") TypedFile file, RetrofitCallback<Response> callback);
//
//	@PUT("/v2/users/plumperfect/")
//	@FormUrlEncoded
//	void changePassword(@Field("current_password") String currentPassowrd, @Field("new_password") String newPassword, @Field("new_password_confirm") String newConfirmPassword, RestError.RetrofitCallback<Response> callback);
//
//	// @POST("/services.php")
//	// void getdata(@Query("data") String requestBody, Callback<Response>
//	// callback);
//	@GET("/v2/user/profiles/")
//	void getProfile(RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/product/filtering/?seller_varinode=1")
//	void getFilterData(RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/sellers/?seller_varinode=1")
//	void getSellerData(RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/user/varinode/cart/products/")
//	void getShoppingList(RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/user/{wishlist}")
//	void getWishList(@Path("wishlist") String wishlist, RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/user/wishlist/")
//	@FormUrlEncoded
//	void addToWishIt(@Field("product_color_id") String productColorId, RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/user/disslist/")
//	@FormUrlEncoded
//	void addToDissIt(@Field("product_color_id") String productColorId, RestError.RetrofitCallback<Response> callback);
//
//	@DELETE("/v2/user/disslist/{product_color_id}")
//	void removeFromDissIt(@Path("product_color_id") String productColorId, RestError.RetrofitCallback<Response> callback);
//
//	@DELETE("/v2/user/wishlist/{product_color_id}")
//	void removeFromWishIt(@Path("product_color_id") String productColorId, RestError.RetrofitCallback<Response> callback);
//
//	// @PATCH
//	@GET("/v2/user/profiles/{id}/products")
//	void getMyMatchProduct(@Path("id") int profileId, @Query(value = "seller_varinode", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/user/profiles/{id}/products")
//	void getMyLook(@Path("id") int profileId, @Query(value = "seller_varinode", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/user/varinode/cart/products/")
//	@FormUrlEncoded
//	void addToCart(@Field("product_color_id") String productColorId, @Field("product_name") String productName, @Field("product_image") String productImage, @Field("product_price") String productPrice, @Field("product_url") String productUrl,
//				   @Field("product_murl") String productMurl, @Field("product_color_hex") String productColorHex, @Field("product_color_name") String productColorName, @Field("varinode_site") String varinodeSite,
//				   @Field("varinode_site_name") String varinodeSiteName, @Field("varinode_product") String varinodeProduct, @Field("product_quantity") String productQuantity, @Field("product_added_from") String productAddedFrom,
//				   @Field("product_why_this_look") String productWhyThisLook, @Field("product_look_name") String productLookName, RestError.RetrofitCallback<Response> callback);
//
//	@PUT("/v2/user/varinode/cart/products/{product_color_id}")
//	@FormUrlEncoded
//	void updateCart(@Path("product_color_id") String productColorId, @Field("product_name") String productName, @Field("product_image") String productImage, @Field("product_price") String productPrice, @Field("product_url") String productUrl,
//					@Field("product_murl") String productMurl, @Field("product_color_hex") String productColorHex, @Field("product_color_name") String productColorName, @Field("varinode_site") String varinodeSite,
//					@Field("varinode_site_name") String varinodeSiteName, @Field("varinode_product") String varinodeProduct, @Field("product_quantity") String productQuantity, @Field("product_added_from") String productAddedFrom,
//					@Field("product_why_this_look") String productWhyThisLook, @Field("product_look_name") String productLookName, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/product/colors/")
//	void getMatchMyMakeup(@Query(value = "product_type_ids", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/product/colors/")
//	void getMatchMyMakeupProductsMatches(@Query(value = "seller_varinode", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/user/match/products")
//	void getPlumSaysMatchData(@Query(value = "profile_id", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/product/colors/")
//	void getSearchData(@Query(value = "seller_varinode", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);
//
//	@PUT("/v2/user/profiles/{id}/references/+{referenceId}")
//	@FormUrlEncoded
//	void uploadColor(@Path("id") String profileId, @Path("referenceId") String referenceId, @Field("color") String color, RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/email/password-reset/")
//	@FormUrlEncoded
//	void forgotPassword(@Field("email") String email, RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/user/profiles/from-model")
//	@FormUrlEncoded
//	void uploadUserModel(@Field("model_id") int modelId, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/models/")
//	void getUserModel(RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/user/varinode/carts/")
//	@FormUrlEncoded
//	void sendCartId(@Field("varinode_cart_id") String varinodeCartId, RestError.RetrofitCallback<Response> callback);
//
//	@DELETE("/v2/user/varinode/cart/products/{productId}")
//	void removeProductFromCart(@Path("productId") String productId, RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/users/plumperfect/")
//	@FormUrlEncoded
//	void userSignup(@Field("email") String email, @Field("password") String password, @Field("first_name") String firstName, @Field("last_name") String lastName, @Field("password_confirm") String passwordConfirm, RestError.RetrofitCallback<Response> callback);
//
//	@DELETE("/v2/sessions/")
//	void userLogout(RestError.RetrofitCallback<Response> callback);
//
//	@PATCH("/v2/user/")
//	@FormUrlEncoded
//	void changeUserDetails(@Field("first_name") String firstName, @Field("last_name") String lastName, RestError.RetrofitCallback<Response> callback);
//
//	@POST("/v2/sessions/facebook/")
//	@FormUrlEncoded
//	void userFacebookLogin(@Field("fb_id") String fbId, @Field("fb_token") String fbToken, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/product/colors/")
//	void getLiveTrendingColorFilterProduct(@Query(value = "seller_varinode", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);
//
//	@GET("/v2/user/profiles/{id}/mylooks/")
//	void getNewMyLook(@Path("id") int profileId, @Query(value = "seller_varinode", encodeValue = false) String appendUrl, RestError.RetrofitCallback<Response> callback);

}
