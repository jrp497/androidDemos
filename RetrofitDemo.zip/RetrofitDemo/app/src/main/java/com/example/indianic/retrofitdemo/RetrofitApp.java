package com.example.indianic.retrofitdemo;

import android.app.Application;

/**
 * Created by indianic on 30/07/15.
 */
public class RetrofitApp extends Application  {

    @Override
    public void onCreate() {
        super.onCreate();
        new RestClient(this);
    }



}
