package com.example.indianic.retrofitdemo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import retrofit.client.Response;

/**
 * Created by indianic on 30/07/15.
 */
public class Utils {

    /**
     * get string from response
     *
     * @param result
     * @return String
     */
    public static String getStringFromResponse(Response result) {
        BufferedReader reader = null;
        StringBuilder sb = new StringBuilder();
        try {

            reader = new BufferedReader(new InputStreamReader(result.getBody().in()));

            String line;

            try {
                while ((line = reader.readLine()) != null) {
                    sb.append(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        String message = sb.toString();
        return message;
    }
}
