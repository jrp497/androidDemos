package com.example.indianic.boundservice;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;

import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

import com.example.indianic.boundservice.BoundService.MyBinder;

public class MainActivity extends Activity {

    Intent intent;
    BoundService mBoundService;
    boolean mServiceBound = false;
    String pausedValue;
    public static long mValueChro = 0;
    public static int cronoflag = 0;
    public boolean cronoflag1 = false;

    int pause_btn = 0;
    int resume_btn = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView timestampText = (TextView) findViewById(R.id.timestamp_text);
        final TextView timestamp2Text = (TextView) findViewById(R.id.timestampDelay_text);

        Button startServiceButton = (Button) findViewById(R.id.start_service);
        startServiceButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                intent = new Intent(MainActivity.this, BoundService.class);
                startService(intent);

                bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
            }
        });

        Button printTimestampButton = (Button) findViewById(R.id.print_timestamp);
        printTimestampButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                if (mServiceBound) {
                    timestampText.setText(mBoundService.getTimestamp());
                }
                else{
                    timestamp2Text.setText(mBoundService.getTimestamp());

                }
            }
        });

        Button resumeServiceButton = (Button) findViewById(R.id.resume_service);
        resumeServiceButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                if(resume_btn == 0) {
//                    Log.e("", "Resume Crono==" + mBoundService.getChronometer());

                    bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
                    intent = new Intent(MainActivity.this, BoundService.class);
                    startService(intent);

//                    Log.e("", "after Resume crono==" + mBoundService.getChronometer());
                    resume_btn = 1;
                    pause_btn = 0;
                }

            }
        });

        Button stopServiceButton = (Button) findViewById(R.id.stop_service);
        stopServiceButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.e("", "value of chrono=="+mBoundService.getChronometer());
                if (mServiceBound) {
                    unbindService(mServiceConnection);
                    mServiceBound = false;
                }
                Intent intent = new Intent(MainActivity.this,
                        BoundService.class);
                stopService(intent);
                cronoflag = 0;
                mValueChro = 0;
                pause_btn = 0;
                resume_btn = 0;
            }
        });

        Button pauseServiceButton = (Button) findViewById(R.id.pause_service);
        pauseServiceButton.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
//                if (mServiceBound) {
//                    unbindService(mServiceConnection);
//                    mServiceBound = false;
//                }
//                Intent intent = new Intent(MainActivity.this,
//                        BoundService.class);
//
//                pausedValue = mBoundService.getTimestamp();
//                Log.v("TAG", "" + pausedValue);
//                stopService(intent);

                if(pause_btn == 0)
                {

                if (mServiceBound) {
                    unbindService(mServiceConnection);
                    mServiceBound = false;
                }
                mValueChro = mBoundService.getChronometer();
                Log.e("", "pause crono=="+mBoundService.getChronometer());

//                mValueChro = mchronometer.getBase() - SystemClock.elapsedRealtime();


                Intent intent = new Intent(MainActivity.this, BoundService.class);
                stopService(intent);

                pause_btn= 1;
                    resume_btn = 0;

                }


            }
        });

    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent intent = new Intent(this, BoundService.class);
        startService(intent);
        bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
        Log.e("TAG contex", "" + Context.BIND_AUTO_CREATE);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mServiceBound) {
            unbindService(mServiceConnection);
            mServiceBound = false;
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    private ServiceConnection mServiceConnection = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            mServiceBound = false;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MyBinder myBinder = (MyBinder) service;
            mBoundService = myBinder.getService();
            mServiceBound = true;
        }
    };
}