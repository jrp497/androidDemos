package com.example.indianic.boundservice;

import android.app.Activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.indianic.boundservice.BoundService.MyBinder;


public class MainActivity extends Activity implements View.OnClickListener {

    BoundService mBoundService;
    Boolean mServiceBound = false;
    TextView timestampText;
    private int pauseFlag = 0, j;
    private int flag_intterupt=0;
    private Button mPauseService, mResume;

    public static long mValueChro = 0;

    final Handler handler = new Handler();
    final Thread runnable = new Thread() {

        @Override
        public void run() {
            if(flag_intterupt==1) {
                threadMethod();
            }
            else
            {
                runnable.interrupt();
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timestampText = (TextView) findViewById(R.id.timestamp_text);
        Button printTimestampButton = (Button) findViewById(R.id.print_timestamp);
        Button stopServiceButon = (Button) findViewById(R.id.stop_service);
        Button startService = (Button) findViewById(R.id.start_service);
        mPauseService = (Button) findViewById(R.id.pause_service);
        mResume = (Button) findViewById(R.id.resume_service);

        printTimestampButton.setOnClickListener(this);
        stopServiceButon.setOnClickListener(this);
        startService.setOnClickListener(this);
        mPauseService.setOnClickListener(this);
        mResume.setOnClickListener(this);


    }

    private void threadMethod() {


//        new Thread() {
//            public void run() {
//

    if (timestampText != null) {
        try {
            runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    timestampText.setText(mBoundService.getTimestamp());
                }
            });

        } catch (Exception e) {
            e.printStackTrace();
        }
        handler.postDelayed(runnable, 10);
    }

//        }.start();
//        final Handler handler = new Handler();
//        handler.postAtTime(new Runnable() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//
//                    @Override
//                    public void run() {
//                        timestampText.setText(mBoundService.getTimestamp());
//                    }
//                });
//            }
//        },1);


    }


    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MyBinder myBinder = (MyBinder) service;
            mBoundService = myBinder.getService();
            mServiceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

            mServiceBound = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
//        Intent intent = new Intent(this, BoundService.class);
//        startService(intent);
//        bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);


    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mServiceBound) {
            unbindService(mServiceConnection);
            mServiceBound = false;
        }
    }


    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.print_timestamp) {
            if (mServiceBound) {

//                threadMethod();
                //runnable.run();
                //timestampText.setText(mBoundService.getTimestamp());
            }
        } else if (v.getId() == R.id.stop_service) {

            if (mServiceBound) {
                unbindService(mServiceConnection);
                mServiceBound = false;
            }
            Intent intent = new Intent(MainActivity.this,
                    BoundService.class);
            mValueChro = 0;
            stopService(intent);
            flag_intterupt = 0;
            runnable.run();


        } else if (v.getId() == R.id.start_service) {

            flag_intterupt=1;
            Intent intent = new Intent(this, BoundService.class);
            startService(intent);
            bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);

            runnable.run();

        } else if (v.getId() == R.id.pause_service) {

            if (pauseFlag == 0) {

                Log.e("", "value of chrono==" + mBoundService.getChronometer());

                mValueChro = mBoundService.getChronometer();
                if (mServiceBound) {
                    unbindService(mServiceConnection);
                    mServiceBound = false;
                }
                Intent intent = new Intent(MainActivity.this,
                        BoundService.class);
                stopService(intent);
                pauseFlag = 1;
                flag_intterupt=0;
                runnable.run();
            }
        } else if (v.getId() == R.id.resume_service) {


            Intent intent = new Intent(this, BoundService.class);
            startService(intent);
            bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);

            pauseFlag = 0;
            flag_intterupt=1;
            runnable.run();
        }

    }


}
