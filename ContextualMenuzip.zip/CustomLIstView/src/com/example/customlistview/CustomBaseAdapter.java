package com.example.customlistview;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class CustomBaseAdapter extends BaseAdapter {

	private ArrayList<ListModel> arrayList;
	private LayoutInflater inflater;
	private Context context;

	public CustomBaseAdapter(final Context context,
			final ArrayList<ListModel> arrayList) {
		this.arrayList = arrayList;
		inflater = ((Activity) context).getLayoutInflater();
		this.context = context;
	}

	@Override
	public int getCount() {
		return arrayList.size();
	}

	@Override
	public ListModel getItem(int position) {
		return arrayList.get(position);
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = inflater.inflate(R.layout.row_item, null);
			holder.imageView = (ImageView) convertView
					.findViewById(R.id.row_item_imageview);
			holder.textViewName = (TextView) convertView
					.findViewById(R.id.row_item_textview_name);
			holder.textViewAddress = (TextView) convertView
					.findViewById(R.id.row_item_textview_address);
			convertView.setTag(holder);

		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		final ListModel listModel = arrayList.get(position);
		holder.textViewName.setText(listModel.getName());
		holder.textViewAddress.setText(listModel.getAddress());
		holder.imageView.setImageResource(listModel.getImageResource());

		holder.imageView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(context, "" + listModel.getName(),
						Toast.LENGTH_SHORT).show();

			}
		});

		return convertView;
	}

	private class ViewHolder {
		private ImageView imageView;
		private TextView textViewName;
		private TextView textViewAddress;
	}
	
	
	public void editDataAtPosition(final int position){
		final ListModel listModel = arrayList.get(position);
		listModel.setName("Mavya");
		arrayList.set(position, listModel);
		notifyDataSetChanged();
	}
	public void remove(final int position){
		arrayList.remove(position);
		notifyDataSetChanged();
	}

}
