package com.example.customlistview;

import java.util.ArrayList;

import android.app.Activity;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		final GridView listView = (GridView) findViewById(R.id.gridview);
		final TextView textview = (TextView) findViewById(R.id.textview);

		final ArrayList<ListModel> arrayList = new ArrayList<ListModel>();

		for (int i = 0; i < 10; i++) {
			final ListModel listModel = new ListModel();
			listModel.setId(i);
			listModel.setName("ILDC" + i);
			listModel.setAddress("ILDC Address" + i);
			listModel.setImageResource(R.drawable.ic_launcher);
			arrayList.add(listModel);
		}

		final CustomBaseAdapter adapter = new CustomBaseAdapter(this, arrayList);
		// CustomArrayAdapter adapter = new CustomArrayAdapter(this,
		// R.layout.row_item, arrayList);
		listView.setAdapter(adapter);

		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {

				final ListModel listModel = (ListModel) parent
						.getItemAtPosition(position);

				if (adapter != null) {
					// adapter.editDataAtPosition(position);
					adapter.remove(position);
				}
				Toast.makeText(MainActivity.this, "" + position,
						Toast.LENGTH_SHORT).show();

			}
		});

		textview.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				ActionMode mActionMode = MainActivity.this
						.startActionMode(new ActionModeCallBack());
			}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	// private class ActionBarCallBack implements ActionMode.Callback {
	//
	// @Override
	// public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
	// // TODO Auto-generated method stub
	// return false;
	// }
	//
	// @Override
	// public boolean onCreateActionMode(ActionMode mode, Menu menu) {
	// // TODO Auto-generated method stub
	// mode.getMenuInflater().inflate(R.menu.contextual_menu, menu);
	// return true;
	// }
	//
	// @Override
	// public void onDestroyActionMode(ActionMode mode) {
	// // TODO Auto-generated method stub
	//
	// }
	//
	// @Override
	// public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
	// // TODO Auto-generated method stub
	//
	// mode.setTitle("CheckBox is Checked");
	// return false;
	// }
	// }

	private class ActionModeCallBack implements Callback {

		@Override
		public boolean onCreateActionMode(ActionMode mode, Menu menu) {
			mode.getMenuInflater().inflate(R.menu.main, menu);
			return true;
		}

		@Override
		public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
			mode.setTitle("TextView");
			
			return false;
		}

		@Override
		public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public void onDestroyActionMode(ActionMode mode) {
			// TODO Auto-generated method stub

		}

	}

}
