package app.inappdemo;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.ServiceConnection;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.android.vending.billing.IInAppBillingService;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

/**
 * Created by indianic on 10/08/15.
 */
public class InAppActivity extends Activity implements View.OnClickListener {
    private Button btnAvailable, btnPurchase, btnQueryForPurchaseItem, btnConsumePurchase, btnSubscribe;
    IInAppBillingService mService;
    static final String SKU_INAPPITEM = "android.test.purchased";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inapp);
        Intent serviceIntent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
        serviceIntent.setPackage("com.android.vending");
        bindService(serviceIntent, mServiceConn, Context.BIND_AUTO_CREATE);
        btnAvailable = (Button) findViewById(R.id.button);
        btnPurchase = (Button) findViewById(R.id.button2);
        btnQueryForPurchaseItem = (Button) findViewById(R.id.button3);
        btnConsumePurchase = (Button) findViewById(R.id.button4);
        btnSubscribe = (Button) findViewById(R.id.button5);
        btnAvailable.setOnClickListener(this);
        btnPurchase.setOnClickListener(this);
        btnQueryForPurchaseItem.setOnClickListener(this);
        btnConsumePurchase.setOnClickListener(this);
        btnSubscribe.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        if (v == btnAvailable)

        {
            ArrayList<String> skuList = new ArrayList<String>();
            skuList.add(SKU_INAPPITEM);
            Bundle querySkus = new Bundle();
            querySkus.putStringArrayList("ITEM_ID_LIST", skuList);
            try {
                Bundle skuDetails = mService.getSkuDetails(3,
                        getPackageName(), "inapp", querySkus);
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else if (v == btnPurchase) {
            try {
                Bundle buyIntentBundle = mService.getBuyIntent(3, getPackageName(),
                        SKU_INAPPITEM, "inapp", "bGoa+V7g/yqDXvKRqq+JTFn4uQZbPiQJo4pf9RzJ");
                PendingIntent pendingIntent = buyIntentBundle.getParcelable("BUY_INTENT");
                startIntentSenderForResult(pendingIntent.getIntentSender(),
                        1001, new Intent(), Integer.valueOf(0), Integer.valueOf(0),
                        Integer.valueOf(0));
            } catch (RemoteException e) {
                e.printStackTrace();
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }
        } else if (v == btnQueryForPurchaseItem) {
            try {
                Bundle ownedItems = mService.getPurchases(3, getPackageName(), "inapp", null);
                int response = ownedItems.getInt("RESPONSE_CODE");
                if (response == 0) {
                    ArrayList<String> ownedSkus =
                            ownedItems.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
                    ArrayList<String> purchaseDataList =
                            ownedItems.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
                    ArrayList<String> signatureList =
                            ownedItems.getStringArrayList("INAPP_DATA_SIGNATURE_LIST");
                    String continuationToken =
                            ownedItems.getString("INAPP_CONTINUATION_TOKEN");

                    for (int i = 0; i < purchaseDataList.size(); ++i) {
                        String purchaseData = purchaseDataList.get(i);
                        String signature = signatureList.get(i);
                        String sku = ownedSkus.get(i);

                        // do something with this purchase information
                        // e.g. display the updated list of products owned by user
                    }

                    // if continuationToken != null, call getPurchases again
                    // and pass in the token to retrieve more items
                }
                Log.e(InAppActivity.class.getSimpleName(), "You have bought the . Excellent choice,adventurer!");
            } catch (RemoteException e) {
                e.printStackTrace();
            }
        } else if (v == btnConsumePurchase) {
            new AsyncConsumePurchase().execute("");
        } else if (v == btnSubscribe) {
            Bundle bundle = null;
            try {
                bundle = mService.getBuyIntent(3, getPackageName(),
                        SKU_INAPPITEM, "subs", "bGoa+V7g/yqDXvKRqq+JTFn4uQZbPiQJo4pf9RzJ");
                PendingIntent pendingIntent = bundle.getParcelable("BUY_INTENT");
                startIntentSenderForResult(pendingIntent.getIntentSender(),
                        1001, new Intent(), Integer.valueOf(0), Integer.valueOf(0),
                        Integer.valueOf(0));
            } catch (RemoteException e) {
                e.printStackTrace();
            } catch (IntentSender.SendIntentException e) {
                e.printStackTrace();
            }


        }
    }

    ServiceConnection mServiceConn = new ServiceConnection() {
        @Override
        public void onServiceDisconnected(ComponentName name) {
            mService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name,
                                       IBinder service) {
            mService = IInAppBillingService.Stub.asInterface(service);
        }
    };

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (mService != null) {
            unbindService(mServiceConn);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1001) {
            int responseCode = data.getIntExtra("RESPONSE_CODE", 0);
            String purchaseData = data.getStringExtra("INAPP_PURCHASE_DATA");
            String dataSignature = data.getStringExtra("INAPP_DATA_SIGNATURE");

            if (resultCode == RESULT_OK) {
                try {
                    JSONObject jo = new JSONObject(purchaseData);
                    String sku = jo.getString("productId");
                    Log.e(InAppActivity.class.getSimpleName(), "You have bought the " + sku + ". Excellent choice,adventurer!");
                } catch (JSONException e) {
                    Log.e(InAppActivity.class.getSimpleName(), "Failed to parse purchase data.");
                    e.printStackTrace();
                }
            }
        }
    }

    private class AsyncConsumePurchase extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            try {
                int response = mService.consumePurchase(3, getPackageName(), "inapp:app.inappdemo:android.test.purchased");
                Log.e(InAppActivity.class.getSimpleName(), "You have bought the  . Excellent choice,adventurer!");
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            return "";
        }
    }
}
