package com.example.indianic.sharedpreference;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends Activity {


    public static  final String MYPREFS="pref";
    public static  final String Name = "namekey";
    public static  final String Phone ="phonekey";



    EditText name,phone;
    Button submit;
    Button retrive;


    SharedPreferences sharedPreferences;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


            name = (EditText)findViewById(R.id.editTextName);
            phone = (EditText)findViewById(R.id.editTextPhone);


            submit = (Button)findViewById(R.id.buttonSubmit);
            retrive = (Button)findViewById(R.id.buttonRetrive);



            sharedPreferences = getSharedPreferences(MYPREFS, Context.MODE_PRIVATE);


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String n = name.getText().toString().trim();
                String p = phone.getText().toString().trim();


                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString(Name,n);
                editor.putString(Phone,p);
                editor.commit();

                Toast.makeText(MainActivity.this,"Thanks",Toast.LENGTH_SHORT).show();


            }


        });


        retrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this,Retrive.class);

                startActivity(intent);

            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
