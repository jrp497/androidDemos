package com.example.indianic.boundservice;

import android.app.Activity;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.indianic.boundservice.BoundService.MyBinder;


public class MainActivity extends Activity implements View.OnClickListener {

    int STARTFLAG = 0;

    BoundService mBoundService;
    Boolean mServiceBound = false;
    TextView timestampText;
    private int pauseFlag = 0, j;
    private int flag_intterupt = 0;
    private Button mPauseService, mResume;
    Button printTimestampButton;
    Button stopServiceButon;
    Button startService;

    public static long mValueChro = 0;

    final Handler handler = new Handler();
    final Thread runnable = new Thread() {


        @Override
        public void run() {
            if (flag_intterupt == 1) {
                threadMethod();
            } else {
                runnable.interrupt();
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        timestampText = (TextView) findViewById(R.id.timestamp_text);

        stopServiceButon = (Button) findViewById(R.id.stop_service);
        startService = (Button) findViewById(R.id.start_service);

        stopServiceButon.setOnClickListener(this);
        startService.setOnClickListener(this);


    }

    private void threadMethod() {


//        new Thread() {
//            public void run() {
//

        if (timestampText != null) {
            try {
                runOnUiThread(new Runnable() {

                    @Override
                    public void run() {
                        timestampText.setText(mBoundService.getTimestamp());
                    }
                });

            } catch (Exception e) {
                e.printStackTrace();
            }
            handler.postDelayed(runnable, 50);
        }

//        }.start();
//        final Handler handler = new Handler();
//        handler.postAtTime(new Runnable() {
//            @Override
//            public void run() {
//                runOnUiThread(new Runnable() {
//
//                    @Override
//                    public void run() {
//                        timestampText.setText(mBoundService.getTimestamp());
//                    }
//                });
//            }
//        },1);


    }


    private ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            MyBinder myBinder = (MyBinder) service;
            mBoundService = myBinder.getService();
            mServiceBound = true;
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {

            mServiceBound = false;
        }
    };

    @Override
    protected void onStart() {
        super.onStart();
//        Intent intent = new Intent(this, BoundService.class);
//        startService(intent);
//        bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);


    }

    @Override
    protected void onStop() {
        super.onStop();
        if (mServiceBound) {
            unbindService(mServiceConnection);
            mServiceBound = false;
        }
    }


    @Override
    public void onClick(View v) {

        if (v.getId() == R.id.stop_service) {

            if (mServiceBound) {
                unbindService(mServiceConnection);
                mServiceBound = false;
            }
            Intent intent = new Intent(MainActivity.this,
                    BoundService.class);
            mValueChro = 0;
            stopService(intent);
            flag_intterupt = 0;
            pauseFlag = 0;
            runnable.run();
            timestampText.setText("");
            STARTFLAG = 0;
            startService.setText("Start Service");


        } else if (v.getId() == R.id.start_service) {

            if (STARTFLAG == 0) {
                Intent intent = new Intent(this, BoundService.class);
                startService(intent);
                bindService(intent, mServiceConnection, Context.BIND_AUTO_CREATE);
                flag_intterupt = 1;
                runnable.run();
                startService.setText("Pause Service");
                STARTFLAG = 1;
            } else {

                mValueChro = mBoundService.getChronometer();
                if (mServiceBound) {
                    unbindService(mServiceConnection);
                    mServiceBound = false;
                }
                Intent intent = new Intent(MainActivity.this, BoundService.class);
                stopService(intent);
                flag_intterupt = 0;
                runnable.run();
                startService.setText("Start Service");
                STARTFLAG = 0;
            }


        }

    }


}
