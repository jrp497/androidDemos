package com.example.amit.jsonparsing;

import java.util.ArrayList;
import java.util.HashMap;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

public class MainActivity extends Activity {

    private ProgressDialog pDialog;
    private Context context;

    // URL to get contacts JSON
    private static String url = "http://mbdbtechnology.com/projects/officeapp/ws/webservice/company_list";


    // JSON Node names
    private static final String TAG_ALL_DATA = "all_data";
    private static final String TAG_COMPANY_ID = "company_id";
    private static final String TAG_COMPANY_NAME = "company_name";
    private static final String TAG_COMPANY_LOGO = "company_logo";

    // contacts JSONArray
    JSONArray contacts = null;
    ListView listView;

    // Hashmap for ListView
    ArrayList<HashMap<String, String>> contactList;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        context = this;


        contactList = new ArrayList<HashMap<String, String>>();


        // Calling async task to get json
        new GetContacts().execute();
    }

    /**
     * Async task class to get json by making HTTP call
     */
    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    contacts = jsonObj.getJSONArray(TAG_ALL_DATA);

                    // looping through All Contacts
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String all_data = c.getString(TAG_COMPANY_ID);
                        String company_name = c.getString(TAG_COMPANY_NAME);
                        String company_logo = c.getString(TAG_COMPANY_LOGO);

                        // Phone node is JSON Object

                        // tmp hashmap for single contact
                        HashMap<String, String> contact = new HashMap<String, String>();


                        // adding each child node to HashMap key => value

                        contact.put(TAG_COMPANY_ID, all_data);
                        contact.put(TAG_COMPANY_NAME, company_name);
                        contact.put(TAG_COMPANY_LOGO, company_logo);
//                        Log.e("TAG", "" + company_logo);

                        // adding contact to contact list
                        contactList.add(contact);
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;
        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();

            /**
             * Updating parsed JSON data into ListView
             * */

            listView = (ListView) findViewById(R.id.activity_main_list);
            CustomBaseAdapter adapter = new CustomBaseAdapter(context, contactList);
            listView.setAdapter(adapter);

        }

    }

}