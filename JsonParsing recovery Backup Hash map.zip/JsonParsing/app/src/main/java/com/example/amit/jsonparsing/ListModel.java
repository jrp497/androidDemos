package com.example.amit.jsonparsing;

import android.graphics.Bitmap;

/**
 * Created by parth on 21/8/15.
 */
public class ListModel {

    private String stringcompany_id;
    private String stringcompany_name;
    private Bitmap bitmapcompany_logo;

    public String getStringcompany_id() {
        return stringcompany_id;
    }

    public void setStringcompany_id(String stringcompany_id) {
        this.stringcompany_id = stringcompany_id;
    }

    public String getStringcompany_name() {
        return stringcompany_name;
    }

    public void setStringcompany_name(String stringcompany_name) {
        this.stringcompany_name = stringcompany_name;
    }

    public Bitmap getBitmapcompany_logo() {
        return bitmapcompany_logo;
    }

    public void setBitmapcompany_logo(Bitmap bitmapcompany_logo) {
        this.bitmapcompany_logo = bitmapcompany_logo;
    }
}
