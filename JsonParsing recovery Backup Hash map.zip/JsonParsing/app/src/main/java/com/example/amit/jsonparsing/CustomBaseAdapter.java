package com.example.amit.jsonparsing;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;

/**
 * Created by Amit on 20-07-2015.
 */

public class CustomBaseAdapter extends BaseAdapter {

    ArrayList<HashMap<String, String>> contactList;
    private LayoutInflater inflater;
    private Context context;
    private MainActivity activity;

    public CustomBaseAdapter(final Context context, final ArrayList<HashMap<String, String>> contactList) {
        this.contactList = contactList;
        inflater = ((Activity) context).getLayoutInflater();
        this.context = context;
        activity = (MainActivity) context;
    }

    @Override
    public int getCount() {
        return contactList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;

        if (convertView == null) {

            holder = new ViewHolder();

            convertView = inflater.inflate(R.layout.list_item, null);

            holder.textViewCOMPANY_ID = (TextView) convertView.findViewById(R.id.id);
            holder.textViewCOMPANY_NAME = (TextView) convertView.findViewById(R.id.name);
            holder.imageViewCOMPANY_LOGO = (ImageView) convertView.findViewById(R.id.logo);
            convertView.setTag(holder);

        } else {

            holder = (ViewHolder) convertView.getTag();
        }

        final HashMap<String, String> listModel = contactList.get(position);

        holder.textViewCOMPANY_ID.setText(listModel.get("company_id"));
        holder.textViewCOMPANY_NAME.setText(listModel.get("company_name"));
        Picasso.with(context)
                .load(listModel.get("company_logo"))
                .placeholder(R.mipmap.ic_launcher)
                .error(R.mipmap.ic_launcher)
                .into(holder.imageViewCOMPANY_LOGO);

        return convertView;
    }

    private class ViewHolder {

        private TextView textViewCOMPANY_ID;
        private TextView textViewCOMPANY_NAME;
        private ImageView imageViewCOMPANY_LOGO;
    }
}