package com.example.indianic.sharedpreference;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.widget.TextView;


/**
 * Created by indianic on 13/07/15.
 */
public class Retrive extends Activity {


    TextView name ,phone;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.retrivedata);

        name = (TextView)findViewById(R.id.textViewDisplayName);
        phone = (TextView)findViewById(R.id.textViewDisplayPhone);


        SharedPreferences sharedPreferences = this.getSharedPreferences("pref", Context.MODE_PRIVATE);

        String n = sharedPreferences.getString("namekey", "");
        String p = sharedPreferences.getString("phonekey","");

        name.setText(n);
        phone.setText(p);


    }
}
