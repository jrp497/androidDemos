package com.example.indianic.contactapidemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.LoaderManager;
import android.content.Context;
import android.content.CursorLoader;
import android.content.Loader;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AlphabetIndexer;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.QuickContactBadge;
import android.widget.SectionIndexer;
import android.widget.TextView;


public class MainActivity extends Activity implements
        LoaderManager.LoaderCallbacks<Cursor> {
    private ContactsAdapter mAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final ListView listView = (ListView) findViewById(R.id.listview);

        mAdapter = new ContactsAdapter(this);
        listView.setAdapter(mAdapter);
        getLoaderManager().restartLoader(
                ContactsQuery.QUERY_ID, null, this);
    }

    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        Log.e("onCreateLoader", "onCreateLoader");
        if (id == ContactsQuery.QUERY_ID) {
            final Uri contentUri = ContactsQuery.CONTENT_URI;
            return new CursorLoader(this,
                    contentUri,
                    ContactsQuery.PROJECTION,
                    ContactsQuery.SELECTION,
                    null,
                    ContactsQuery.SORT_ORDER);
        }
        return null;
    }

    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        if (loader.getId() == ContactsQuery.QUERY_ID) {
            mAdapter.swapCursor(data);
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        if (loader.getId() == ContactsQuery.QUERY_ID) {
            mAdapter.swapCursor(null);
        }
    }


    private class ContactsAdapter extends CursorAdapter {
        private LayoutInflater mInflater; // Stores the layout inflater
//        private AlphabetIndexer mAlphabetIndexer; // Stores the AlphabetIndexer instance
//        private TextAppearanceSpan highlightTextSpan; // Stores the highlight text appearance style

        public ContactsAdapter(Context context) {
            super(context, null, 0);
            mInflater = LayoutInflater.from(context);
            final String alphabet = context.getString(R.string.alphabet);
//            mAlphabetIndexer = new AlphabetIndexer(null, ContactsQuery.SORT_KEY, alphabet);
//            highlightTextSpan = new TextAppearanceSpan(MainActivity.this, R.style.searchTextHiglight);
        }

//        private int indexOfSearchQuery(String displayName) {
//            if (!TextUtils.isEmpty(mSearchTerm)) {
//                return displayName.toLowerCase(Locale.getDefault()).indexOf(
//                        mSearchTerm.toLowerCase(Locale.getDefault()));
//            }
//            return -1;
//        }

        @Override
        public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
            final View itemLayout =
                    mInflater.inflate(R.layout.contact_list_item, viewGroup, false);
            final ViewHolder holder = new ViewHolder();
            holder.text1 = (TextView) itemLayout.findViewById(android.R.id.text1);
            holder.text2 = (TextView) itemLayout.findViewById(android.R.id.text2);
            holder.icon = (QuickContactBadge) itemLayout.findViewById(android.R.id.icon);
            itemLayout.setTag(holder);
            return itemLayout;
        }

        @Override
        public void bindView(View view, Context context, Cursor cursor) {
            final ViewHolder holder = (ViewHolder) view.getTag();
            final String photoUri = cursor.getString(ContactsQuery.PHOTO_THUMBNAIL_DATA);
            final String displayName = cursor.getString(ContactsQuery.DISPLAY_NAME);
//            final int startIndex = indexOfSearchQuery(displayName);
//            if (startIndex == -1) {
            holder.text1.setText(displayName);
//                if (TextUtils.isEmpty(mSearchTerm)) {
            holder.text2.setVisibility(View.GONE);
//                } else {
//                    holder.text2.setVisibility(View.VISIBLE);
//                }
//            }
//            else {
//                final SpannableString highlightedName = new SpannableString(displayName);
//                highlightedName.setSpan(highlightTextSpan, startIndex,
//                        startIndex + mSearchTerm.length(), 0);
//                holder.text1.setText(highlightedName);
//                holder.text2.setVisibility(View.GONE);
//            }
//            final Uri contactUri = ContactsContract.Contacts.getLookupUri(
//                    cursor.getLong(ContactsQuery.ID),
//                    cursor.getString(ContactsQuery.LOOKUP_KEY));
//            holder.icon.assignContactUri(contactUri);
//            mImageLoader.loadImage(photoUri, holder.icon);
        }

//        @Override
//        public Cursor swapCursor(Cursor newCursor) {
//            mAlphabetIndexer.setCursor(newCursor);
//            return super.swapCursor(newCursor);
//        }

        @Override
        public int getCount() {
            if (getCursor() == null) {
                return 0;
            }
            return super.getCount();
        }

//        @Override
//        public Object[] getSections() {
//            return mAlphabetIndexer.getSections();
//        }
//
//        @Override
//        public int getPositionForSection(int i) {
//            if (getCursor() == null) {
//                return 0;
//            }
//            return mAlphabetIndexer.getPositionForSection(i);
//        }
//
//        @Override
//        public int getSectionForPosition(int i) {
//            if (getCursor() == null) {
//                return 0;
//            }
//            return mAlphabetIndexer.getSectionForPosition(i);
//        }

        private class ViewHolder {
            TextView text1;
            TextView text2;
            QuickContactBadge icon;
        }
    }


    public interface ContactsQuery {
        final static int QUERY_ID = 1;
        final static Uri CONTENT_URI = ContactsContract.Contacts.CONTENT_URI;
        final static Uri FILTER_URI = ContactsContract.Contacts.CONTENT_FILTER_URI;
        @SuppressLint("InlinedApi")
        final static String SELECTION =
                (Utils.hasHoneycomb() ? ContactsContract.Contacts.DISPLAY_NAME_PRIMARY : ContactsContract.Contacts.DISPLAY_NAME) +
                        "<>''" + " AND " + ContactsContract.Contacts.IN_VISIBLE_GROUP + "=1";

        @SuppressLint("InlinedApi")
        final static String SORT_ORDER =
                Utils.hasHoneycomb() ? ContactsContract.Contacts.SORT_KEY_PRIMARY : ContactsContract.Contacts.DISPLAY_NAME;
        @SuppressLint("InlinedApi")
        final static String[] PROJECTION = {
                ContactsContract.Contacts._ID,
                ContactsContract.Contacts.LOOKUP_KEY,
                Utils.hasHoneycomb() ? ContactsContract.Contacts.DISPLAY_NAME_PRIMARY : ContactsContract.Contacts.DISPLAY_NAME,
                Utils.hasHoneycomb() ? ContactsContract.Contacts.PHOTO_THUMBNAIL_URI : ContactsContract.Contacts._ID,
                SORT_ORDER,
        };

        final static int ID = 0;
        final static int LOOKUP_KEY = 1;
        final static int DISPLAY_NAME = 2;
        final static int PHOTO_THUMBNAIL_DATA = 3;
        final static int SORT_KEY = 4;
    }

}
