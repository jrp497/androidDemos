package com.example.indianic.intentservice;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by indianic on 07/07/15.
 */
public class SimpleIntentServiceDemo extends IntentService{


    public SimpleIntentServiceDemo() {
        super("SimpleIntentServiceDemo");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        if (intent != null && intent.getExtras() != null) {
            final String name = intent.getStringExtra("red");
            Log.e("TAG", "Intent Service started "  + name);

        }
    }
}
