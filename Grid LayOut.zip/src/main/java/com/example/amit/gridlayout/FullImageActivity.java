package com.example.amit.gridlayout;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

public class FullImageActivity extends Activity {
 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.full_image);

        // get intent data
        Intent i = getIntent();

        // Selected image id
        int position = i.getExtras().getInt("id");
        Log.e("TAG------full--Position",""+position);
        ImageAdapter imageAdapter = new ImageAdapter(this);
        Log.e("TAG------full--Position",""+imageAdapter.getItemId(position));

        ImageView imageView = (ImageView) findViewById(R.id.full_image_view);
//        imageView.setImageResource(imageAdapter.mThumbIds[position]);
        Picasso.with(this)
                .load(imageAdapter.mThumbIds[position])
                .resize(300,400)
                .centerCrop()
                .into(imageView);
    }
 
}