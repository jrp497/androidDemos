package com.finallayout.jaypatel.fragmentactivity;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.View.OnClickListener;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by Jay Patel on 7/9/2015.
 */
public class FragmentTwo extends Fragment{


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragmentlayout_two, null);
        init(view);
        return view;

    }

    private void init(View view) {

        final Button button =(Button)view.findViewById(R.id.buttonNext2);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                final FragmentThree fragmentThree= new FragmentThree();
//                final Bundle bundle = new Bundle();
//                bundle.putString("key_Name", "Mavya");
//                fragmentTwo.setArguments(bundle);
                ((MainActivity)getActivity()).addFragment(FragmentTwo.this,fragmentThree);

            }
        });

        final Button back =(Button)view.findViewById(R.id.buttonBack2);
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });

    }
}
