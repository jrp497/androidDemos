package com.finallayout.jaypatel.fragmentactivity;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.view.View.OnClickListener;

/**
 * Created by Jay Patel on 7/9/2015.
 */
public class FragmentThree extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.fragmentlayout_three, null);
        init(view);


        return view;
    }

    public void init(View view) {

        final Button button = (Button) view.findViewById(R.id.buttonNext3);
        button.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                final FragmentOne fragmentOne = new FragmentOne();
//                final Bundle bundle = new Bundle();
//                bundle.putString("key_Name", "Mavya");
//                fragmentTwo.setArguments(bundle);
                ((MainActivity) getActivity()).addFragment(FragmentThree.this, fragmentOne);
            }
        });

        final Button back = (Button)view.findViewById(R.id.buttonBack3);
        back.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                getFragmentManager().popBackStack();
            }
        });

    }

}
