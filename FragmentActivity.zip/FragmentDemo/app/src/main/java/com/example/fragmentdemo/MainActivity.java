package com.example.fragmentdemo;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		replaceFragment(new HomeFragment());
	}

	public void replaceFragment(final Fragment fragment) {
		final FragmentManager fragmentManager = getFragmentManager();
		final FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();
		fragmentTransaction.replace(R.id.container, fragment, fragment
				.getClass().getSimpleName());
		fragmentTransaction.commit();

	}

	public void addFragment(final Fragment hideFragment,
			final Fragment newFragment) {
		final FragmentManager fragmentManager = getFragmentManager();
		final FragmentTransaction fragmentTransaction = fragmentManager
				.beginTransaction();
		fragmentTransaction.add(R.id.container, newFragment, newFragment
				.getClass().getSimpleName());
		fragmentTransaction.hide(hideFragment);
		fragmentTransaction.addToBackStack(newFragment.getClass()
				.getSimpleName());
		fragmentTransaction.commit();
	}

	// @Override
	// public void onBackPressed() {
	// if (getFragmentManager().getBackStackEntryCount() > 0) {
	// getFragmentManager().popBackStack();
	// } else {
	// super.onBackPressed();
	// }
	// }

	@Override
	public void onBackPressed() {
		if (getFragmentManager().getBackStackEntryCount() > 0) {
			getFragmentManager().popBackStack();
		} else {
			super.onBackPressed();
		}
	}

}
