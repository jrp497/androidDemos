package com.example.servicedemo;

import android.app.IntentService;
import android.content.Intent;

public class SimpleIntentService extends IntentService {

	public SimpleIntentService() {
		super("SimpleIntentService");
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		if (intent != null && intent.getExtras() != null) {
			final String name = intent.getStringExtra("key_name");

		}

	}

}
