package com.example.servicedemo;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.TextView;

public class MainActivity extends ActionBarActivity {

	private int j = 0;
	private TextView textView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		textView = (TextView) findViewById(R.id.textview);

		// new Thread() {
		// public void run() {
		// for (j = 0; j < 1000; j++) {
		// try {
		// runOnUiThread(new Runnable() {
		//
		// @Override
		// public void run() {
		// textView.setText("#" + j);
		// }
		// });
		// Thread.sleep(300);
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// }
		// }
		// }.start();

		textView.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				final Intent intent = new Intent("com.Service");
				intent.putExtra("name", "Mavya");
				sendBroadcast(intent);

			}
		});

		// final UpdateAsync updateAsync = new UpdateAsync(1, "Mavya");
		// updateAsync.execute("Mavya", "Mavya", "Mavya");

		// new Runnable() {
		//
		// @Override
		// public void run() {
		// for (j = 0; j < 1000; j++) {
		// try {
		// runOnUiThread(new Runnable() {
		//
		// @Override
		// public void run() {
		// textView.setText("#" + j);
		// }
		// });
		// Thread.sleep(300);
		//
		//
		// } catch (InterruptedException e) {
		// e.printStackTrace();
		// }
		// }
		// }
		// };

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private class UpdateAsync extends AsyncTask<String, Integer, Void> {

		private ProgressDialog progressDialog;

		private int id;
		private String name;

		public UpdateAsync(final int id, final String name) {
			this.id = id;
			this.name = name;
		}

		@Override
		protected void onPreExecute() {
			super.onPreExecute();
			progressDialog = ProgressDialog.show(MainActivity.this,
					getString(R.string.app_name), "loading...");
		}

		@Override
		protected Void doInBackground(String... params) {

			Log.e("TAG0", params[0]);
			Log.e("TAG1", params[1]);
			Log.e("TAG2", params[2]);

			for (j = 0; j < 50; j++) {
				try {
					Thread.sleep(300);
					publishProgress(j);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			return null;
		}

		@Override
		protected void onProgressUpdate(final Integer... values) {
			super.onProgressUpdate(values);
			runOnUiThread(new Runnable() {

				@Override
				public void run() {
					textView.setText("#" + values[0]);
				}
			});

		}

		@Override
		protected void onPostExecute(Void result) {
			super.onPostExecute(result);
			if (progressDialog != null && progressDialog.isShowing()) {
				progressDialog.dismiss();
			}
		}

	}

}
