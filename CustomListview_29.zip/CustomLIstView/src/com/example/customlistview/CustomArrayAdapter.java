package com.example.customlistview;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class CustomArrayAdapter extends ArrayAdapter<ListModel> {

	private LayoutInflater layoutInflater;
	private ArrayList<ListModel> arrayList;

	public CustomArrayAdapter(Context context, int resource,
			ArrayList<ListModel> arrayList) {
		super(context, resource, arrayList);
		layoutInflater = ((Activity) context).getLayoutInflater();
		this.arrayList = arrayList;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {

		ViewHolder holder;
		if (convertView == null) {
			holder = new ViewHolder();
			convertView = layoutInflater.inflate(R.layout.row_item, null);
			holder.imageView = (ImageView) convertView
					.findViewById(R.id.row_item_imageview);
			holder.textViewName = (TextView) convertView
					.findViewById(R.id.row_item_textview_name);
			holder.textViewAddress = (TextView) convertView
					.findViewById(R.id.row_item_textview_address);
			convertView.setTag(holder);

		} else {
			holder = (ViewHolder) convertView.getTag();
		}

		final ListModel listModel = arrayList.get(position);
		holder.textViewName.setText(listModel.getName());
		holder.textViewAddress.setText(listModel.getAddress());
		holder.imageView.setImageResource(listModel.getImageResource());

		return convertView;
	}

	private class ViewHolder {
		private ImageView imageView;
		private TextView textViewName;
		private TextView textViewAddress;
	}

}
