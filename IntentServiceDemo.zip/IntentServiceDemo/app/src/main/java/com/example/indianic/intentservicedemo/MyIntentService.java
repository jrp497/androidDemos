package com.example.indianic.intentservicedemo;

import android.app.IntentService;
import android.content.Intent;
import android.os.SystemClock;
import android.text.format.DateFormat;
import android.util.Log;

/**
 * Created by indianic on 08/07/15.
 */
public class MyIntentService extends IntentService {


     public MyIntentService() {

        super("MyIntentService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {

        if(intent != null && intent.getExtras()!= null){

            final String name = intent.getStringExtra("prashant");
            Log.e("TAG", "Intent service start" + name);

        }

    }
}
