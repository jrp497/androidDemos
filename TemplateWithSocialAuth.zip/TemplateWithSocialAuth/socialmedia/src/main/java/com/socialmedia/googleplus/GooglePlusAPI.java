package com.socialmedia.googleplus;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentSender;
import android.os.Bundle;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.plus.Plus;
import com.google.android.gms.plus.model.people.Person;
import com.socialmedia.utils.Method;

public class GooglePlusAPI {


    public static final int SIGN_IN = 1001;
    public static final int SHARE = 1002;
    private static GooglePlusAPI instance;
    private GoogleApiClient googleApiClient;
    private Method currentMethod;
    private GooglePlusInterface googlePlusInterface;
    private Intent intent;

    public GooglePlusAPI() {
        instance = this;
    }

    public static GooglePlusAPI getInstance() {
        return GooglePlusAPI.instance;
    }

    public final void init(final Activity context) {

        googleApiClient = new GoogleApiClient.Builder(context).addConnectionCallbacks(new GoogleApiClient.ConnectionCallbacks() {
            @Override
            public void onConnected(Bundle bundle) {
                switch (currentMethod) {
                    case PROFILE:
                        getPersonInformation(currentMethod, googlePlusInterface);
                        break;
                    case SHARE:
                        share(context, currentMethod, intent);
                        break;
                }
            }

            @Override
            public void onConnectionSuspended(int i) {

            }
        }).addOnConnectionFailedListener(new GoogleApiClient.OnConnectionFailedListener() {
            @Override
            public void onConnectionFailed(ConnectionResult connectionResult) {
                try {
                    connectionResult.startResolutionForResult(context, SIGN_IN);
                } catch (IntentSender.SendIntentException e) {
                    // The intent was canceled before it was sent.  Return to the default
                    // state and attempt to connect to get an updated ConnectionResult.
                    googleApiClient.connect();
                }
            }
        }).addApi(Plus.API).addScope(Plus.SCOPE_PLUS_LOGIN).build();

    }

    public final void connect() {
        if (googleApiClient != null && !googleApiClient.isConnected()) {
            googleApiClient.connect();
        }
    }

    public final void disconnect() {
        if (googleApiClient != null && googleApiClient.isConnected()) {
            Plus.AccountApi.clearDefaultAccount(googleApiClient);
            googleApiClient.disconnect();
            instance = null;
        }
    }


    public void getPersonInformation(final Method method, GooglePlusInterface googlePlusInterface) {
        this.currentMethod = method;
        this.googlePlusInterface = googlePlusInterface;
        if (googleApiClient.isConnected() && Plus.PeopleApi.getCurrentPerson(googleApiClient) != null) {
            Person person = Plus.PeopleApi.getCurrentPerson(googleApiClient);
            googlePlusInterface.getMyProfile(person);
        } else {
            connect();
        }

    }


    /*public final boolean checkGooglePlusInstalled(final Context context) {
        int errorCode = GooglePlusUtil.checkGooglePlusApp(this);
        if (errorCode != GooglePlusUtil.SUCCESS) {
            GooglePlusUtil.getErrorDialog(errorCode, this, 0).show();
            return false;
        } else {
            return true;
        }
    }*/

    public GoogleApiClient getGoogleApiClient() {
        return googleApiClient;
    }

    public void share(Activity activity, Method method, Intent intent) {
        currentMethod = method;
        this.intent = intent;
        if (googleApiClient.isConnected()) {
            activity.startActivityForResult(intent, SHARE);
        } else {
            connect();
        }

    }
}
