/*
 * Copyright (c) 2015. $user
 */

package com.socialmedia.twitter;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Toast;

import com.socialmedia.R;

import java.io.File;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.User;
import twitter4j.auth.AccessToken;
import twitter4j.auth.RequestToken;
import twitter4j.conf.Configuration;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.media.ImageUpload;
import twitter4j.media.ImageUploadFactory;
import twitter4j.media.MediaProvider;

/**
 * This class contain twitter login - logout method. this class also save the
 * login data into shared preference. Class contains method for share Text as
 * well as image. It will prompt for Login if not done earlier or directly will
 * share the data if logged in done and session is live.
 *
 * @author
 * @version 1.0
 * @date
 */
public class TwitterLogin {

    static final String USER_NAME = "user_name";
    /**
     * Sharedpreference variables
     */
    public static String PREFERENCE_NAME = "twitter_oauth";
    public static String PREF_KEY_SECRET = "oauth_token_secret";
    public static String PREF_KEY_TOKEN = "oauth_token";
    /**
     * Twitter variable
     */
    private static Twitter twitter;
    private static RequestToken requestToken;
    private final String TAG = this.getClass().getSimpleName();
    /**
     * Text to share on Twitter
     */
    private String textToShare = "";
    /**
     * ImagePath for the image which user want to share on Twitter
     */
    private String imagePathToShare = "";
    private Context mcontext;
    /**
     * Twitter App information mentioned in strings.xml Which you need to add as
     * per your app added in developer.twitter.com site
     */
    private String CALLBACK_URL = "";
    private String twitterConsumerKey = "";
    private String twitterConsumerSecretKey = "";
    private SharedPreferences mSharedPreferences;
    /**
     * boolean set for Share twitter using in App Dialog or Third party browser
     */
    private boolean isDialog_Login = true;

    @SuppressWarnings("static-access")
    public TwitterLogin(Context context, String consumerKey, String consumerSecretKey, String callBackURL) {
        mcontext = context;
        mSharedPreferences = context.getSharedPreferences(PREFERENCE_NAME, context.MODE_PRIVATE);
        twitterConsumerKey = consumerKey;
        twitterConsumerSecretKey = consumerSecretKey;
        CALLBACK_URL = callBackURL;
    }

    public static Twitter getTwitterInstance() {
        return twitter;
    }

    /**
     * This method open the twitter login screen & do the twitter login
     */
    public void login() {

        new TwitterLoginTask().execute();

    }

    /**
     * Check Whether User logged in or not in Twitter Pass text which you want
     * to share on Twitter. blank if no text Pass Image Path for image which you
     * want to share on Twitter. blank if no image to share
     *
     * @param mcontext
     * @param text
     * @param imagePath
     */
    public void checkLoginForTwitter(Context mcontext, String text, String imagePath) {
        this.mcontext = mcontext;
        this.textToShare = text;
        this.imagePathToShare = imagePath;

        new CheckLoginTask().execute();
    }

    /**
     * This method check for twitter login & return boolean value according to
     * login status
     */
    public boolean checkLogin() {
        try {

            final String token = mSharedPreferences.getString(PREF_KEY_TOKEN, "");
            final String secret = mSharedPreferences.getString(PREF_KEY_SECRET, "");

            if (!token.equalsIgnoreCase("") && !secret.equalsIgnoreCase("")) {

                final ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
                configurationBuilder.setOAuthConsumerKey(twitterConsumerKey);
                configurationBuilder.setOAuthConsumerSecret(twitterConsumerSecretKey);
                final Configuration configuration = configurationBuilder.build();

                final AccessToken a = new AccessToken(token, secret);
                twitter = new TwitterFactory(configuration).getInstance();

                try {
                    requestToken = twitter.getOAuthRequestToken(CALLBACK_URL);
                    twitter.setOAuthAccessToken(a);
                    twitter.getAccountSettings();

                    final User user = twitter.verifyCredentials();
                    Log.e(TAG, "User Name:" + user.getName());
                    Log.e(TAG, "Screen Name:" + user.getScreenName());
                    final SharedPreferences.Editor editor = mSharedPreferences.edit();
                    editor.putString(USER_NAME, user.getName());
                    editor.commit();

                    return true;
                } catch (TwitterException e) {
                    e.printStackTrace();
                    return false;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    /**
     * This method get the user screen name & save the data into shared
     * preference
     */
    public void accessTwitter(Context context, Uri uri) {
        // final Uri uri = ((Activity) context).getIntent().getData();
        if (uri != null && uri.toString().startsWith(CALLBACK_URL)) {
            final String verifier = uri.getQueryParameter(context.getString(R.string.callback_verifier));
            if (verifier != null)
                new AccessTwitterTask(context, verifier).execute();
        }
    }

    /**
     * This method persists the Access Token information so that a user is not
     * required to re-login every time the app is used
     *
     * @param accessToken - the access token
     */
    private void storeAccessToken(AccessToken accessToken) {

        final SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString(PREF_KEY_TOKEN, accessToken.getToken());
        editor.putString(PREF_KEY_SECRET, accessToken.getTokenSecret());
        editor.commit();
    }

    /**
     * This method do the twitter logout & remove the token data from shared
     * preference
     */
    public void logout() {
        final SharedPreferences.Editor editor = mSharedPreferences.edit();
        editor.putString(PREF_KEY_TOKEN, "");
        editor.putString(PREF_KEY_SECRET, "");
        editor.putString(USER_NAME, "");
        editor.commit();
    }

    /**
     * Twitter connection is availalbe or not
     *
     * @return
     */
    public boolean isConnected() {
        final String token = mSharedPreferences.getString(PREF_KEY_TOKEN, "");
        final String secret = mSharedPreferences.getString(PREF_KEY_SECRET, "");

        if (!token.equalsIgnoreCase("") && !secret.equalsIgnoreCase("")) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Method used for Share Twitter Image and Link Pass text which you want to
     * share on Twitter. blank if no text Pass Image Path for image which you
     * want to share on Twitter. blank if no image to share
     *
     * @param context
     * @param text
     * @param imagePath
     */
    public void postToTwitter(Context context, String text, String imagePath) {
        this.textToShare = text;
        this.imagePathToShare = imagePath;

        SharedImageTask sharedTask = new SharedImageTask(context);
        sharedTask.execute();
    }

    /**
     * Used for post text as well as image to Twitter
     *
     * @return
     */
    private boolean shareImage() {

        final AccessToken a = new AccessToken(mSharedPreferences.getString(PREF_KEY_TOKEN, ""), mSharedPreferences.getString(PREF_KEY_SECRET, ""));

        final Configuration conf = new ConfigurationBuilder().setOAuthConsumerKey(twitterConsumerKey).setOAuthConsumerSecret(twitterConsumerSecretKey).setOAuthAccessToken(a.getToken()).setOAuthAccessTokenSecret(a.getTokenSecret()).build();

        final ImageUploadFactory factory = new ImageUploadFactory(conf);
        final ImageUpload upload = factory.getInstance(MediaProvider.TWITTER);
        try {
            if (TextUtils.isEmpty(imagePathToShare)) {
                twitter = new TwitterFactory(conf).getInstance();
                twitter.updateStatus(textToShare);
            } else {
                upload.upload(new File(imagePathToShare), textToShare);
                Log.e(TAG, "Success to send image");
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();

            Log.e(TAG, e.toString());
            // logout();
            // checkLoginForTwitter(mcontext);
            return false;
        }

    }

    /**
     * This Asynctask is for start login process for Twitter.
     */
    public class TwitterLoginTask extends AsyncTask<Void, Void, Void> {
        private ProgressDialog mProgressDialog;

        /**
         * Display the dialog first when the webservice call.
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (mcontext != null) {
                mProgressDialog = ProgressDialog.show(mcontext, "", mcontext.getString(R.string.please_wait), true, false);

            }

        }

        @Override
        protected Void doInBackground(Void... params) {
            // The factory instance is re-useable and thread safe.

            final ConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
            configurationBuilder.setOAuthConsumerKey(twitterConsumerKey);
            configurationBuilder.setOAuthConsumerSecret(twitterConsumerSecretKey);
            final Configuration configuration = configurationBuilder.build();
            twitter = new TwitterFactory(configuration).getInstance();

            try {
                requestToken = twitter.getOAuthRequestToken(CALLBACK_URL);
                // Toast.makeText(MainActivity.this,
                // "Please authorize this app!",
                // Toast.LENGTH_LONG).show();
            } catch (TwitterException e) {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(Void result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);
            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            if (isDialog_Login) {
                new Intent(Intent.ACTION_VIEW, Uri.parse(requestToken.getAuthenticationURL()));
                new TwitterWebView((Activity) mcontext, requestToken.getAuthenticationURL(), TwitterLogin.this);
            } else {
                final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(requestToken.getAuthenticationURL())).setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_NO_HISTORY | Intent.FLAG_FROM_BACKGROUND);
                mcontext.startActivity(intent);
            }
        }
    }

    /**
     * Check About Twitter logged in or not
     *
     * @author indianic
     */
    public class CheckLoginTask extends AsyncTask<Void, Void, Boolean> {

        private ProgressDialog mProgressDialog;

        /**
         * Display the dialog first when the webservice call.
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (mcontext != null) {
                mProgressDialog = ProgressDialog.show(mcontext, "", mcontext.getString(R.string.please_wait), true, false);

            }

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // The factory instance is re-useable and thread safe.

            return checkLogin();

        }

        @Override
        protected void onPostExecute(Boolean result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);

            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            if (result) {
                Log.d(TAG, "You are Already Logged in");
                postToTwitter(mcontext, textToShare, imagePathToShare);
            } else {
                login();
            }
        }
    }

    /**
     * Handle as per response received after enter credential to Twitter
     *
     * @author indianic
     */
    public class AccessTwitterTask extends AsyncTask<Void, Void, Void> {

        private String verifier;

        private Context callbackcontext;

        private ProgressDialog mProgressDialog;

        private String errorMessage = "";// , userId = "", email = "", fulName =
        // "", userName = "";

        public AccessTwitterTask(Context context, String verifier) {
            this.callbackcontext = context;
            this.verifier = verifier;
        }

        /**
         * Display the dialog first when the webservice call.
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (callbackcontext != null) {
                mProgressDialog = ProgressDialog.show(callbackcontext, "", callbackcontext.getString(R.string.please_wait), true, false);
                mProgressDialog.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
            }
            mProgressDialog.setOnCancelListener(new OnCancelListener() {

                @Override
                public void onCancel(DialogInterface dialog) {
                    cancel(true);
                }
            });

        }

        @Override
        protected void onCancelled() {
            super.onCancelled();

        }

        @Override
        protected Void doInBackground(Void... params) {
            // The factory instance is re-useable and thread safe.
            try {
                final AccessToken accessToken = twitter.getOAuthAccessToken(requestToken, verifier);
                storeAccessToken(accessToken);

                Log.e("Testing", ":" + accessToken.getToken());

                final User user = twitter.verifyCredentials();

                final SharedPreferences.Editor editor = mSharedPreferences.edit();
                editor.putString(USER_NAME, user.getName());
                editor.commit();

                // userId = String.valueOf(user.getId());
                // email = "";
                // fulName = user.getName();
                // userName = user.getScreenName();

            } catch (Exception e) {
                Log.e(TAG, "" + e.getMessage());
                e.printStackTrace();
                errorMessage = e.getMessage();

            }
            return null;

        }

        @Override
        protected void onPostExecute(Void result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);

            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            if (errorMessage != null) {
                if (errorMessage.length() > 0) {
                    Toast.makeText(callbackcontext, "Twitter Login failed", Toast.LENGTH_LONG).show();
                } else {
                    /**
                     * If on successfull Login to Twitter We required any
                     * information of loggedIn user than we can retrieve and use
                     * as per blow commented code
                     */
                    // if (mcontext instanceof MainActivity) {
                    // ((MainActivity)
                    // mcontext).onSuccessFullTwitterLogin(email, fulName,
                    // userId, userName);
                    // } else {
                    // postToTwitter(mcontext, textToShare, imagePathToShare);
                    // }
                    postToTwitter(mcontext, textToShare, imagePathToShare);
                }
            }

        }
    }

    public class SharedImageTask extends AsyncTask<Void, Void, Boolean> {

        private ProgressDialog mProgressDialog;

        private Context mcontext1;

        public SharedImageTask(Context context) {
            // TODO Auto-generated constructor stub
            mcontext1 = context;
            mcontext = context;
        }

        /**
         * Display the dialog first when the webservice call.
         */
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            if (mcontext1 != null) {
                mProgressDialog = ProgressDialog.show(mcontext1, "", mcontext.getString(R.string.please_wait), true, false);
            }

        }

        @Override
        protected Boolean doInBackground(Void... params) {
            // The factory instance is re-useable and thread safe.

            return shareImage();

        }

        @Override
        protected void onPostExecute(Boolean result) {
            // TODO Auto-generated method stub
            super.onPostExecute(result);

            if (mProgressDialog != null && mProgressDialog.isShowing()) {
                mProgressDialog.dismiss();
            }
            if (result) {
                logout();
                Toast.makeText(mcontext, mcontext.getString(R.string.twitter_success_post), Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(mcontext, mcontext.getString(R.string.twitter_error_post), Toast.LENGTH_SHORT).show();

            }

        }
    }
}
