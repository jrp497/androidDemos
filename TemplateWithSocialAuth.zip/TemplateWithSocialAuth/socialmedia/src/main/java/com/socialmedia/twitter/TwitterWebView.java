/*
 * Copyright (c) 2015. $user
 */

package com.socialmedia.twitter;

import android.app.Activity;
import android.app.Dialog;
import android.net.Uri;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;

import com.socialmedia.R;

public class TwitterWebView extends Dialog
{
    WebView webView;

    Activity activity;

    ProgressBar progressBar;

    public TwitterWebView(final Activity context, String url, final TwitterLogin twitterLogin)
    {
        super(context);
        this.activity = context;
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.twitterwebview);

        getWindow().setLayout(RelativeLayout.LayoutParams.MATCH_PARENT, RelativeLayout.LayoutParams.MATCH_PARENT);

        progressBar = (ProgressBar) findViewById(R.id.progressBar1);

        webView = (WebView) findViewById(R.id.webview_twitter);
        getWindow().setFeatureInt(Window.FEATURE_PROGRESS, Window.PROGRESS_VISIBILITY_ON);
        webView.loadUrl(url);
        webView.getSettings().setJavaScriptEnabled(true);

        webView.setWebViewClient(new WebViewClient() {

                                     @Override
                                     public void onPageFinished(WebView view, String url) {
                                         progressBar.setVisibility(View.GONE);
                                         super.onPageFinished(view, url);
                                     }

                                     @Override
                                     public boolean shouldOverrideUrlLoading(WebView view, String url) {
                                         Log.e(getClass().getSimpleName(), url);
                                         if (url.contains(activity.getString(R.string.callback_verifier))) {
                                             // Designate Urls that you want to load in WebView still.
                                             twitterLogin.accessTwitter(activity, Uri.parse(url));
                                             dismiss();
                                             return true;
                                         } else if (url.contains(activity.getString(R.string.denied))) {
                                             dismiss();
                                             return true;
                                         } else {
                                             view.loadUrl(url);
                                         }
                                         // Otherwise, give the default behavior (open in browser)
                                         return true;
                                     }
                                 }

        );

        show();
    }

}
