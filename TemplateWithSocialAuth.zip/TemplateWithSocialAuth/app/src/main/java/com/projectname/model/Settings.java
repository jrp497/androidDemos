package com.projectname.model;

/**
 * Created by on 29/05/15.
 */

public class Settings {


    private String message;
    private Integer success;
    private Integer statusCode;


    /**
     *
     * @return
     * The message
     */
   public String getMessage() {
        return message;
    }

    /**
     *
     * @param message
     * The message
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     *
     * @return
     * The success
     */
    public Integer getSuccess() {
        return success;
    }

    /**
     *
     * @param success
     * The success
     */

    public void setSuccess(Integer success) {
        this.success = success;
    }

    /**
     *
     * @return
     * The statusCode
     */

    public Integer getStatusCode() {
        return statusCode;
    }

    /**
     *
     * @param statusCode
     * The statusCode
     */

    public void setStatusCode(Integer statusCode) {
        this.statusCode = statusCode;
    }


}

