package com.projectname.view;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.projectname.R;
import com.projectname.TemplateAplication;
import com.projectname.model.ForgotPasswordService;
import com.projectname.util.Constans;
import com.projectname.util.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import retrofit.mime.TypedInput;


public class ForgotPasswordActivity extends Activity implements OnClickListener
{

    private ImageView ivBack;
    private EditText etEmail;
    private Button btnSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);


        Log.d("","onCreate");

        initializeComponent();


    }


    private void initializeComponent() {

        btnSubmit = (Button) findViewById(R.id.activity_forgot_password_btnSubmit);
        etEmail = (EditText) findViewById(R.id.activity_forgot_password_etEmail);
        ivBack = (ImageView) findViewById(R.id.activity_forgot_password_ivBack);

        ivBack.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);
    }

    /**
     * field level validations
     */
    private void validateFields()
    {
        String email = etEmail.getText().toString().trim();

        if (email.equals(""))
        {
            Utils.displayDialog(this, getString(R.string.app_name), getString(R.string.val_enter_email), getString(android.R.string.ok), "", false, false);
            etEmail.requestFocus();
        }
        else if (!Utils.isValidEmail(email))
        {
            Utils.displayDialog(this, getString(R.string.val_enter_email_in), getString(R.string.val_valid_email), getString(android.R.string.ok), "", false, false);
            etEmail.requestFocus();
        }
        else
        {
            if (Utils.isOnline(ForgotPasswordActivity.this, true))
            {
                getServicesResponse();


            }
        }
    }

    /**
     * for get login service response
     */
    private void getServicesResponse()
    {
        final ProgressDialog mDialog = Utils.showProgressDialog(this, getString(R.string.please_wait), false);
        try
        {
            TypedInput in = new TypedByteArray(getString(R.string.wsHeader), generateRequestJson().getBytes("utf-8"));
            TemplateAplication.getmInstance().getmRetrofitInterface().ForgotPasswordService(in, new Callback<ForgotPasswordService>()
            {
                @Override
                public void success(ForgotPasswordService responceModel, Response arg1)
                {
                    mDialog.dismiss();


                    if (responceModel.getSettings().getSuccess() == 1)
                    {
                        Utils.displayDialog(ForgotPasswordActivity.this, getString(R.string.app_name),""+ responceModel.getSettings().getMessage(),
                                getString(android.R.string.ok), "", false, false);

                        finish();
                    }
                    else
                    {
                        Utils.displayDialog(ForgotPasswordActivity.this, getString(R.string.app_name), responceModel.getSettings().getMessage(),
                                getString(android.R.string.ok), "", false, false);
                    }

                }

                @Override
                public void failure(RetrofitError retrofitError)
                {
                    mDialog.dismiss();
                    Utils.displayDialog(ForgotPasswordActivity.this, getString(R.string.app_name), retrofitError.getMessage(), getString(android.R.string.ok), "", false, false);
                }
            });
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * @return string object of requested json passed as input parameters
     */
    private String generateRequestJson()
    {
        final JSONObject jsonObject = new JSONObject();
        final JSONObject jsonObjectMain = new JSONObject();


        try
        {
            jsonObject.put(getString(R.string.params_email), etEmail.getText().toString().trim());
            jsonObjectMain.put(getString(R.string.params_request), jsonObject);
            jsonObjectMain.put(getString(R.string.params_service), Constans.service_forgotpassword);
            jsonObjectMain.put(getString(R.string.params_method), "POST");


        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        return jsonObject.toString();
    }

    @Override
    public void onBackPressed()
    {
        super.onBackPressed();
        finish();
        overridePendingTransition(R.anim.anim_left_in, R.anim.anim_right_out);
    }



    @Override
    public void onClick(View v)
    {
        Utils.hideKeyboard(ForgotPasswordActivity.this);

        switch (v.getId())
        {
            case R.id.activity_forgot_password_btnSubmit:
                validateFields();
                break;
            case R.id.activity_forgot_password_ivBack:
                finish();


                overridePendingTransition(R.anim.anim_left_in, R.anim.anim_right_out);
                break;
        }
    }
}
