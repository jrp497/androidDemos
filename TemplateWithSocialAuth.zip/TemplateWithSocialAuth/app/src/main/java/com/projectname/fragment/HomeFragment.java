package com.projectname.fragment;

import android.app.Fragment;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import com.projectname.R;
import com.projectname.TemplateAplication;
import com.projectname.adapter.HomeListAdapter;
import com.projectname.model.HomeListService;
import com.projectname.model.HomeResponseList;
import com.projectname.util.Utils;
import com.projectname.view.BaseActivity;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import retrofit.mime.TypedInput;


public class HomeFragment extends Fragment
{

    private ListView lvList;
    private HomeListAdapter mHomeListAdapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState)
    {

        final View rootView = inflater.inflate(R.layout.fragment_home, container, false);
        initializeComponent(rootView);
        return rootView;
    }

    private void initializeComponent(View view)
    {
        lvList=(ListView)view.findViewById(R.id.fragment_home_lvList);

       // callWebServices();
        setCustomActionBar();
    }

    public void callWebServices()
    {
        if (Utils.isOnline(getActivity(), true))
        {
            getServicesResponse();


        }
    }

    /**
     * for get project list service response
     */
    private void getServicesResponse()
    {
        final ProgressDialog mDialog = Utils.showProgressDialog(getActivity(), getString(R.string.please_wait), false);
        try
        {
            TypedInput in = new TypedByteArray(getString(R.string.wsHeader), generateRequestJson().getBytes("utf-8"));
            TemplateAplication.getmInstance().getmRetrofitInterface().ProjectListService(in, new Callback<HomeListService>()
            {
                @Override
                public void success(HomeListService responceModel, Response arg1)
                {
                    mDialog.dismiss();
                    if (responceModel.getProjectListResult().getSystemStatus().equalsIgnoreCase("true"))
                    {
                        if (responceModel.getProjectListResult().getProjectResponseList() != null)
                        {
                            ArrayList<HomeResponseList> arrProjectResponseList = new ArrayList<HomeResponseList>();
                            arrProjectResponseList.addAll(responceModel.getProjectListResult().getProjectResponseList());

                            lvList.setAdapter(null);
                            if (arrProjectResponseList.size() > 0)
                            {
                                mHomeListAdapter = new HomeListAdapter(HomeFragment.this, getActivity(), arrProjectResponseList);
                                lvList.setAdapter(mHomeListAdapter);
                            }
                        }
                        else
                        {
                            Utils.displayDialog(getActivity(), getString(R.string.app_name), responceModel.getProjectListResult().getServiceMsg(),
                                    getString(android.R.string.ok), "", false, false);
                        }
                    }
                    else
                    {
                        Utils.displayDialog(getActivity(), getString(R.string.app_name), responceModel.getProjectListResult().getServiceMsg(),
                                getString(android.R.string.ok), "", false, false);
                    }
                }

                @Override
                public void failure(RetrofitError retrofitError)
                {
                    mDialog.dismiss();
                    Utils.displayDialog(getActivity(), getString(R.string.app_name), retrofitError.getMessage(), getString(android.R.string.ok), "", false, false);
                }
            });
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * @return string object of requested json passed as input parameters
     */
    private String generateRequestJson()
    {
        final JSONObject jsonObject = new JSONObject();
        try
        {
            String loginID = TemplateAplication.getmInstance().getSharedPreferences().getString(getString(R.string.params_userID), "");
            jsonObject.put(getString(R.string.params_userID), loginID);

        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        return jsonObject.toString();
    }


    /****************************************************************************
     *
     * @purpose:This Method use to setCustomActionBar
     *
     ***************************************************************************/

    public void setCustomActionBar()
    {

        ((BaseActivity) getActivity()).setUpActionbar();
        ((BaseActivity) getActivity()).getActionbar_tv_title().setText(getString(R.string.app_name));
        //((BaseActivity) getActivity()).getActionbarivNext().setImageResource(R.drawable.create_btn);


        //((BaseActivity) getActivity()).getActionbarivNext().setOnClickListener(this);
        // ((BaseActivity) getActivity()).getActionbarivBack().setOnClickListener(this);

    }


    /**
     * Called when coming back from next screen
     */
    @Override
    public void onHiddenChanged(boolean hidden)
    {
        super.onHiddenChanged(hidden);
        if (!hidden)
        {

        }
    }


}
