package com.projectname.model;

public class HomeListService
{
	private HomeListResult ProjectListResult;

	/**
	 * @return The HomeListResult
	 */
	public HomeListResult getProjectListResult()
	{
		return ProjectListResult;
	}

	/**
	 * @param ProjectListResult
	 *            The HomeListResult
	 */
	public void setProjectListResult(HomeListResult ProjectListResult)
	{
		this.ProjectListResult = ProjectListResult;
	}
}
