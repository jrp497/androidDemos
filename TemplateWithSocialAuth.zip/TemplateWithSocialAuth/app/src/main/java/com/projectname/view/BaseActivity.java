package com.projectname.view;

import android.app.ActionBar;
import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;

import com.projectname.R;
import com.projectname.TemplateAplication;

/**
 * *************************************************************************
 *
 * @ClassdName:BaseActivity
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is BaseActivity.
 * <p/>
 * *************************************************************************
 */

public abstract class BaseActivity extends Activity
{

    private ActionBar actionBar;
    private ImageView actionbarivBack;
    private ImageView actionbarivNext;
    private TextView actionbartvTitle;
    private TemplateAplication templateAplication;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().requestFeature(Window.FEATURE_ACTION_BAR);
        setContentView(R.layout.activity_base);


        templateAplication = (TemplateAplication) this.getApplication();

        // ActionBar setUp
        actionBar = getActionBar();
        actionBar.setDisplayShowCustomEnabled(true);
        actionBar.setDisplayShowHomeEnabled(false);
        actionBar.setDisplayUseLogoEnabled(false);
        actionBar.setDisplayShowTitleEnabled(false);

        setUpActionbar();


    }

    @Override
    public void onResume() {

        super.onResume();


    }


    public void setUpActionbar() {
        final View actionbarView = LayoutInflater.from(this).inflate(R.layout.actionbar_home, null, true);
        setActionbarivBack((ImageView) actionbarView.findViewById(R.id.activity_base_actionbar_ivBack));
        setActionbarivNext((ImageView) actionbarView.findViewById(R.id.activity_base_actionbar_ivNext));
        setActionbartvTitle((TextView) actionbarView.findViewById(R.id.activity_base_actionbar_tvTitle));
        actionBar.setCustomView(actionbarView);
    }

    public ImageView getActionbarivBack() {
        return actionbarivBack;
    }

    public void setActionbarivBack(ImageView actionbarImgBack) {
        this.actionbarivBack = actionbarImgBack;
    }

    public ImageView getActionbarivNext() {
        return actionbarivNext;
    }

    public void setActionbarivNext(ImageView actionbarImgNext) {
        this.actionbarivNext = actionbarImgNext;
    }

    public TextView getActionbar_tv_title() {
        return actionbartvTitle;
    }

    public void setActionbartvTitle(TextView actionbartvTitle) {
        this.actionbartvTitle = actionbartvTitle;
    }


}
