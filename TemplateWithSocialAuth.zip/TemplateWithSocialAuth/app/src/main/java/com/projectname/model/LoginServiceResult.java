package com.projectname.model;

public class LoginServiceResult
{

    private String UserID;
    private String USERNAME;
    private String deviceToken;


    /**
     * @return The UserID
     */
    public String getUserID() {
        return UserID;
    }

    /**
     * @param UserID The UserID
     */

    public void setUserID(String UserID) {
        this.UserID = UserID;
    }

    /**
     * @return The USERNAME
     */
    public String getUSERNAME() {
        return USERNAME;
    }

    /**
     * @param USERNAME The USERNAME
     */
    public void setUSERNAME(String USERNAME) {
        this.USERNAME = USERNAME;
    }

    /**
     * @return The deviceToken
     */
    public String getDeviceToken() {
        return deviceToken;
    }

    /**
     * @param deviceToken The deviceToken
     */
    public void setDeviceToken(String deviceToken) {
        this.deviceToken = deviceToken;
    }


}
