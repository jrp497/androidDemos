package com.projectname.util;

/**
 * Created by on 30/05/15.
 */
public class Constans
{

    public static String service_login="login";
    public static String service_signup="signup";
    public static String service_forgotpassword="forgotpassword";


}
