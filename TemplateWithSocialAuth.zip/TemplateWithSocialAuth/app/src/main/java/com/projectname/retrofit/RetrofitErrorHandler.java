

package com.projectname.retrofit;

import java.net.SocketTimeoutException;
import java.net.UnknownHostException;

import retrofit.ErrorHandler;
import retrofit.RetrofitError;


/**
 * *************************************************************************
 * RetrofitErrorHandler
 *
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is user for Url ErrorHandler .
 * <p/>
 * *************************************************************************
 */

public class RetrofitErrorHandler implements ErrorHandler {
    public RetrofitErrorHandler() {
    }

    @SuppressWarnings("deprecation")
    @Override
    public Throwable handleError(RetrofitError cause) {
        if (cause.isNetworkError()) {
            if (cause.getCause() instanceof SocketTimeoutException) {
                new CustomException("socket time out");
            }
            if (cause.getCause() instanceof UnknownHostException) {
                new CustomException("no internet connection");

            }
        } else {
            new CustomException("some error occur");
        }
        return cause.getCause();
    }
}
