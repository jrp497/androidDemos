package com.projectname.model;

import com.google.gson.annotations.SerializedName;

public class LoginService
{
	@SerializedName("data")
	private LoginServiceResult LoginServiceResult;

	@SerializedName("settings")
	private Settings Settings;



	/**
	 * @return The LoginServiceResult
	 */
	public LoginServiceResult getLoginServiceResult()
	{
		return LoginServiceResult;
	}

	/**
	 * @param LoginServiceResult
	 *            The LoginServiceResult
	 */
	public void setLoginServiceResult(LoginServiceResult LoginServiceResult)
	{
		this.LoginServiceResult = LoginServiceResult;
	}

	/**
	 * @return The Settings
	 */
	public  Settings getSettings()
	{
		return Settings;
	}

	/**
	 * @param settings
	 *
	 */
	public void setSettings(Settings settings) {
		Settings = settings;
	}
}
