package com.projectname.view;

import android.app.Activity;
import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.projectname.R;
import com.projectname.TemplateAplication;
import com.projectname.model.SignUpService;
import com.projectname.util.Constans;
import com.projectname.util.Utils;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import retrofit.mime.TypedInput;


/****************************************************************************
 * SignUpActivity
 *
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is user for SignUp to user.
 *
 ***************************************************************************/

public class SignUpActivity extends Activity implements OnClickListener
{


    private EditText etFirstName;
    private EditText etCompanyName;
    private EditText etPhoneNo;
    private EditText etAddress;
    private EditText etEmail;
    private EditText etPassword;
    private  EditText etPinCode;

    private ImageView ivBack;
    private Button btnSubmit;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);

        initializeComponent();


    }


    private void initializeComponent() {

        btnSubmit = (Button) findViewById(R.id.activity_signup_btnSignUp);
        ivBack = (ImageView) findViewById(R.id.activity_signup_ivBack);
        etFirstName = (EditText) findViewById(R.id.activity_signup_etFirstname);
        etCompanyName = (EditText) findViewById(R.id.activity_signup_etCompanyName);
        etPhoneNo = (EditText) findViewById(R.id.activity_signup_etPhoneNo);
        etAddress = (EditText) findViewById(R.id.activity_signup_etAddress);
        etEmail = (EditText) findViewById(R.id.activity_signup_etEmail);
        etPinCode=(EditText)findViewById(R.id.activity_signup_etPin);
        etPassword = (EditText) findViewById(R.id.activity_signup_etPassword);

        ivBack.setOnClickListener(this);
        btnSubmit.setOnClickListener(this);

    }

    /**
     * field level validations
     */
    private void validateFields()
    {
        String firstName = etFirstName.getText().toString().trim();
        String companyName = etCompanyName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (firstName.equals(""))
        {
            Utils.displayDialog(this, getString(R.string.app_name), getString(R.string.val_enter_firstname), getString(android.R.string.ok), "", false, false);
            etEmail.requestFocus();
        }
        else if (companyName.equals(""))
        {
            Utils.displayDialog(this, getString(R.string.app_name), getString(R.string.val_enter_companyname), getString(android.R.string.ok), "", false, false);
            etCompanyName.requestFocus();
        }
        else if (email.equals(""))
        {
            Utils.displayDialog(this, getString(R.string.app_name), getString(R.string.val_enter_email), getString(android.R.string.ok), "", false, false);
            etEmail.requestFocus();
        }
        else if (!Utils.isValidEmail(email))
        {
            Utils.displayDialog(this, getString(R.string.val_enter_email_in), getString(R.string.val_valid_email), getString(android.R.string.ok), "", false, false);
            etEmail.requestFocus();
        }
        else if (password.equals(""))
        {
            Utils.displayDialog(this, getString(R.string.app_name), getString(R.string.val_enter_password), getString(android.R.string.ok), "", false, false);
            etPassword.requestFocus();
        }
        else
        {
            if (Utils.isOnline(SignUpActivity.this, true))
            {
                getServicesResponse();


            }
        }
    }

    /**
     * for get login service response
     */
    private void getServicesResponse()
    {
        final ProgressDialog mDialog = Utils.showProgressDialog(this, getString(R.string.please_wait), false);
        try
        {
            TypedInput in = new TypedByteArray(getString(R.string.wsHeader), generateRequestJson().getBytes("utf-8"));
            TemplateAplication.getmInstance().getmRetrofitInterface().signUpService(in, new Callback<SignUpService>()
            {
                @Override
                public void success(SignUpService responceModel, Response arg1)
                {
                    mDialog.dismiss();

                    if (responceModel.getSettings().getSuccess() == 1)
                    {
                        Utils.displayDialog(SignUpActivity.this, getString(R.string.app_name),""+ responceModel.getSettings().getMessage(),
                                getString(android.R.string.ok), "", false, false);

                        finish();
                    }
                    else
                    {
                        Utils.displayDialog(SignUpActivity.this, getString(R.string.app_name), responceModel.getSettings().getMessage(),
                                getString(android.R.string.ok), "", false, false);
                    }
                }

                @Override
                public void failure(RetrofitError retrofitError)
                {
                    mDialog.dismiss();
                    Utils.displayDialog(SignUpActivity.this, getString(R.string.app_name), retrofitError.getMessage(), getString(android.R.string.ok), "", false, false);
                }
            });
        }
        catch (UnsupportedEncodingException e)
        {
            e.printStackTrace();
        }
    }

    /**
     * @return string object of requested json passed as input parameters
     */
    private String generateRequestJson()
    {
        final JSONObject jsonObject = new JSONObject();
        final JSONObject jsonObjectMain = new JSONObject();

        try
        {
            jsonObject.put(getString(R.string.params_firstname), etFirstName.getText().toString().trim());
            jsonObject.put(getString(R.string.params_companyname), etCompanyName.getText().toString().trim());
            jsonObject.put(getString(R.string.email), etEmail.getText().toString().trim());
            jsonObject.put(getString(R.string.params_password), etPassword.getText().toString().trim());
            jsonObject.put(getString(R.string.params_pincode), etPinCode.getText().toString().trim());
            jsonObject.put(getString(R.string.params_mobile_phone), etPhoneNo.getText().toString().trim());
            jsonObject.put("main_phone_number", "9898984545");
            jsonObject.put(getString(R.string.params_address), etAddress.getText().toString().trim());
            jsonObject.put(getString(R.string.params_deviceID), Utils.getDeviceID(this));
            jsonObject.put(getString(R.string.params_apiKey),"c686bc4e7fa22584ef6fa83c8b8d6");


            jsonObjectMain.put(getString(R.string.params_request), jsonObject);
            jsonObjectMain.put(getString(R.string.params_service), Constans.service_signup);
            jsonObjectMain.put(getString(R.string.params_method), "POST");

            Log.d("", "jsonObject Req:-" + jsonObjectMain.toString());


        }
        catch (JSONException e)
        {
            e.printStackTrace();
        }
        return jsonObject.toString();
    }


    @Override
    public void onClick(View v)
    {

        Utils.hideKeyboard(SignUpActivity.this);

        switch (v.getId())
        {
            case R.id.activity_signup_btnSignUp:
                validateFields();
                break;
            case R.id.activity_signup_ivBack:
                finish();
                overridePendingTransition(R.anim.anim_left_in, R.anim.anim_right_out);
                break;
        }

    }
}
