package com.projectname;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import com.nostra13.universalimageloader.cache.disc.naming.Md5FileNameGenerator;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.nostra13.universalimageloader.core.ImageLoaderConfiguration;
import com.nostra13.universalimageloader.core.assist.QueueProcessingType;
import com.projectname.retrofit.RetrofitErrorHandler;
import com.projectname.retrofit.RetrofitInterface;
import com.squareup.okhttp.OkHttpClient;
import retrofit.RestAdapter;
import retrofit.client.OkClient;

/**
 * *************************************************************************
 * TemplateAplication
 *
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This application class to set application level variable and method which
 * used through-out application
 * <p/>
 * *************************************************************************
 */

public class TemplateAplication extends Application
{


    private static TemplateAplication mInstance;
    private SharedPreferences sharedPreferences;
    private static RetrofitInterface mRetrofitInterface;
    public ImageLoader imageLoader;

    public RetrofitInterface getmRetrofitInterface()
    {
        return mRetrofitInterface;
    }


    /**
     * Called when application start
     */
    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;

        initImageLoader();

        sharedPreferences = getSharedPreferences(getString(R.string.app_name), Context.MODE_PRIVATE);

        final OkHttpClient okHttpClient = new OkHttpClient();

        RestAdapter restAdapter = new RestAdapter.Builder().setClient(new OkClient(okHttpClient)).setErrorHandler(new RetrofitErrorHandler()).setLogLevel(RestAdapter.LogLevel.FULL)
                .setEndpoint(getString(R.string.base_url)).build();

        mRetrofitInterface = restAdapter.create(RetrofitInterface.class);
    }

    public static void setmInstance(TemplateAplication mInstance)
    {
        TemplateAplication.mInstance = mInstance;
    }

    public static TemplateAplication getmInstance()
    {
        return mInstance;
    }



    private void initImageLoader() {
        final ImageLoaderConfiguration config = new ImageLoaderConfiguration.Builder(this).threadPriority(Thread.MAX_PRIORITY - 2).denyCacheImageMultipleSizesInMemory()
                .diskCacheFileNameGenerator(new Md5FileNameGenerator()).diskCacheSize(50 * 1024 * 1024)
                        // 50
                .tasksProcessingOrder(QueueProcessingType.LIFO).writeDebugLogs().build();
        // Initialise ImageLoader with configuration.
        imageLoader = ImageLoader.getInstance();
        imageLoader.init(config);
    }

    public SharedPreferences getSharedPreferences() {
        return sharedPreferences;
    }

    public void setSharedPreferences(SharedPreferences sharedPreferences) {
        this.sharedPreferences = sharedPreferences;
    }

    public void savePreferenceDataString(String key, String value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(key, value);
        editor.commit();
    }

    public void savePreferenceDataBoolean(String key, Boolean value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(key, value);
        editor.commit();
    }

    public void savePreferenceDataInt(String key, int value) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt(key, value);
        editor.commit();
    }

    public ImageLoader getImageLoader() {
        return imageLoader;
    }

    /**
     * Call when application is close
     */
    @Override
    public void onTerminate() {
        super.onTerminate();
        if (mInstance != null) {
            mInstance = null;
        }
    }


}
