package com.projectname.retrofit;

import com.projectname.model.ForgotPasswordService;
import com.projectname.model.HomeListService;
import com.projectname.model.LoginService;
import com.projectname.model.SignUpService;

import retrofit.Callback;
import retrofit.http.Body;
import retrofit.http.POST;
import retrofit.mime.TypedInput;

/**
 * *************************************************************************
 * RetrofitInterface
 *
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is user For defining all web-services methods to store data in related model
 *          by retrofit library
 * <p/>
 * *************************************************************************
 */

public interface RetrofitInterface
{
	@POST("/api.php")
	void loginService(@Body TypedInput req, Callback<LoginService> mCallback);

	@POST("/api.php")
	void signUpService(@Body TypedInput req, Callback<SignUpService> mCallback);

	@POST("/api.php")
	void ForgotPasswordService(@Body TypedInput req, Callback<ForgotPasswordService> callback);

	@POST("/api.php")
	void ProjectListService(@Body TypedInput req, Callback<HomeListService> mCallback);



}
