package com.projectname.linkedIn;

public class Config {
	public static String LINKEDIN_CONSUMER_KEY = "7512dgxqiiv4se";
	public static String LINKEDIN_CONSUMER_SECRET = "33tQnCt5rr4fEFAn";
	public static String scopeParams = "rw_nus+r_basicprofile";

	public static String OAUTH_CALLBACK_SCHEME = "x-oauthflow-linkedin";
	public static String OAUTH_CALLBACK_HOST = "callback";
	public static String OAUTH_CALLBACK_URL = OAUTH_CALLBACK_SCHEME + "://" + OAUTH_CALLBACK_HOST;
}
