package com.projectname.retrofit;


/**
 * *************************************************************************
 * RetrofitErrorHandler
 *
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is user for handle the service exception by retrofit
 * <p/>
 * *************************************************************************
 */


public class CustomException extends Exception {
    private static final long serialVersionUID = 1L;

    public CustomException() {
        super();
    }

    public CustomException(String detailMessage, Throwable throwable) {
        super(detailMessage, throwable);
    }

    public CustomException(String detailMessage) {
        super(detailMessage);
    }

    public CustomException(Throwable throwable) {
        super(throwable);
    }
}
