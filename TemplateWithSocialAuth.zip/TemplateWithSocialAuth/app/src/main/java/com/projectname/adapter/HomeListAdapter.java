package com.projectname.adapter;


import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.projectname.R;
import com.projectname.TemplateAplication;
import com.projectname.fragment.HomeFragment;
import com.projectname.model.HomeResponseList;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * *************************************************************************
 *
 * @ClassdName:HomeListAdapter
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This class is use to Adapter on PoiList
 * <p/>
 * *************************************************************************
 */

public class HomeListAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<HomeResponseList> HomeList = null;
    private ArrayList<HomeResponseList> arraylist;
    private DisplayImageOptions displayImageOptions;
    private TemplateAplication dyrctApplication;
    private HomeFragment mFragment;

    public HomeListAdapter(HomeFragment fragment, Context context, List<HomeResponseList> glcContactsListArr) {

        this.context = context;
        this.HomeList = (ArrayList<HomeResponseList>) glcContactsListArr;
        this.mFragment = fragment;
        dyrctApplication = (TemplateAplication) context.getApplicationContext();
        dyrctApplication.getImageLoader();

        this.arraylist = new ArrayList<HomeResponseList>();
        this.arraylist.addAll(HomeList);

        displayImageOptions = new DisplayImageOptions.Builder().cacheInMemory(true).showImageOnLoading(R.drawable.profile).showImageForEmptyUri(R.drawable.profile)
                .showImageOnFail(R.drawable.profile).cacheInMemory(true).bitmapConfig(Bitmap.Config.RGB_565).build();

    }

    @Override
    public int getCount() {

        return HomeList.size();
    }

    @Override
    public HomeResponseList getItem(int position) {
        return HomeList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    public void filter(String searchText) {
        searchText = searchText.toLowerCase(Locale.getDefault());
        HomeList.clear();
        if (searchText.length() == 0) {
            HomeList.addAll(arraylist);
        } else {
            for (HomeResponseList mList : arraylist) {
                if (mList.getName().toLowerCase(Locale.getDefault()).contains(searchText)) {
                    HomeList.add(mList);
                }
            }
        }

        notifyDataSetChanged();
    }

    /**
     * *************************************************************************
     *
     * @Method:-getView
     * @purpose:This method use to Declaration of view & initializeComponent .
     * <p/>
     * *************************************************************************
     */

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        final Holder holder;

        if (convertView == null) {
            holder = new Holder();
            convertView = LayoutInflater.from(context).inflate(R.layout.row_home_list, null);

            holder.tvName = (TextView) convertView.findViewById(R.id.row_home_list_tvName);
            holder.tvAddress = (TextView) convertView.findViewById(R.id.row_home_list_tvAddress);
            holder.ivProfilePic = (ImageView) convertView.findViewById(R.id.row_home_list_ivProfile);

            convertView.setTag(holder);
        } else {
            holder = (Holder) convertView.getTag();
        }

        holder.tvName.setText("" + HomeList.get(position).getName());


        return convertView;
    }

    class Holder {

        private TextView tvName;
        private TextView tvAddress;
        private ImageView ivProfilePic;

    }

}
