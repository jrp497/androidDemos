package com.projectname.view;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.code.linkedinapi.client.LinkedInApiClient;
import com.google.code.linkedinapi.client.LinkedInApiClientFactory;
import com.google.code.linkedinapi.client.enumeration.ProfileField;
import com.google.code.linkedinapi.client.oauth.LinkedInAccessToken;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthService;
import com.google.code.linkedinapi.client.oauth.LinkedInOAuthServiceFactory;
import com.google.code.linkedinapi.client.oauth.LinkedInRequestToken;
import com.google.code.linkedinapi.schema.Person;
import com.projectname.R;
import com.projectname.TemplateAplication;
import com.projectname.linkedIn.Config;
import com.projectname.model.LoginService;
import com.projectname.util.Constans;
import com.projectname.util.Utils;
import com.socialmedia.facebook.FacebookAPI;
import com.socialmedia.facebook.FacebookInterface;
import com.socialmedia.googleplus.GooglePlusAPI;
import com.socialmedia.googleplus.GooglePlusInterface;
import com.socialmedia.twitter.TwitterLogin;
import com.socialmedia.utils.Method;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.util.Arrays;
import java.util.Collection;
import java.util.EnumSet;

import retrofit.Callback;
import retrofit.RetrofitError;
import retrofit.client.Response;
import retrofit.mime.TypedByteArray;
import retrofit.mime.TypedInput;




/**
 * *************************************************************************
 * LoginActivity
 *
 * @CreatedDate:
 * @ModifiedBy: not yet
 * @ModifiedDate: not yet
 * @purpose:This Class is user for login into application through valid credentials.
 * <p/>
 * *************************************************************************
 */


public class LoginActivity extends Activity implements OnClickListener {

    private TextView tvSignUp;
    private TextView tvForgotPassword;
    private TextView tvFblogin;
    private TextView tvTwitter;
    private TextView tvGooglePluslogin;
    private TextView tvLinkedInlogin;
    private EditText etEmail;
    private EditText etPassword;
    private Button btnLogin;


    //Twitter
    private static final String CONSUMER_KEY = "TbUtcQanz3a0A75OgOwnA";
    private static final String CONSUMER_SECRET = "XuevxpeX5ZG8sEr0ZhcFnzTbhxqIUNQy6pjrzfnhk";
    private static final String CALLBACK_URL = "appname://appnamecallback";
    private final Collection<String> permissions = Arrays.asList("publish_actions");
    private TwitterLogin twitterLogin;
    private TextView profileTextView;

    //LinkedIn
    final LinkedInOAuthService oAuthService = LinkedInOAuthServiceFactory.getInstance().createLinkedInOAuthService( Config.LINKEDIN_CONSUMER_KEY,Config.LINKEDIN_CONSUMER_SECRET);
    final LinkedInApiClientFactory factory = LinkedInApiClientFactory .newInstance(Config.LINKEDIN_CONSUMER_KEY, Config.LINKEDIN_CONSUMER_SECRET);
    LinkedInRequestToken liToken;
    LinkedInApiClient client;
    LinkedInAccessToken accessToken = null;



    public String TAG = "LoginActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        if( Build.VERSION.SDK_INT >= 9){
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }


        new FacebookAPI();
        new GooglePlusAPI();

        FacebookAPI.getInstance().init(this);
        FacebookAPI.getInstance().setPermissions(this.permissions);
        GooglePlusAPI.getInstance().init(this);


        initializeComponent();


    }

    /**
     * Method is used for initializeComponent
     */

    private void initializeComponent() {

        Utils.hideKeyboard(LoginActivity.this);


        btnLogin = (Button) findViewById(R.id.activity_login_btnLogin);
        tvSignUp = (TextView) findViewById(R.id.activity_login_tvSignUp);
        tvForgotPassword = (TextView) findViewById(R.id.activity_login_tvForgotPassword);
        tvFblogin = (TextView) findViewById(R.id.activity_login_tvFblogin);
        tvTwitter = (TextView) findViewById(R.id.activity_login_tvTwitterlogin);
        tvLinkedInlogin= (TextView) findViewById(R.id.activity_login_tvLinkedInlogin);
        tvGooglePluslogin= (TextView) findViewById(R.id.activity_login_tvGooglePluslogin);

        etEmail = (EditText) findViewById(R.id.activity_login_etEmail);
        etPassword = (EditText) findViewById(R.id.activity_login_etPassword);

        btnLogin.setOnClickListener(this);
        tvSignUp.setOnClickListener(this);
        tvFblogin.setOnClickListener(this);
        tvTwitter.setOnClickListener(this);
        tvLinkedInlogin.setOnClickListener(this);
        tvGooglePluslogin.setOnClickListener(this);
        tvForgotPassword.setOnClickListener(this);
    }

    /**
     * field level validations
     */
    private void validateFields() {
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString().trim();

        if (email.equals("")) {
            Utils.displayDialog(this, getString(R.string.app_name), getString(R.string.val_enter_email), getString(android.R.string.ok), "", false, false);
            etEmail.requestFocus();
        } else if (!Utils.isValidEmail(email)) {
            Utils.displayDialog(this, getString(R.string.val_enter_email_in), getString(R.string.val_valid_email), getString(android.R.string.ok), "", false, false);
            etEmail.requestFocus();
        } else if (password.equals("")) {
            Utils.displayDialog(this, getString(R.string.app_name), getString(R.string.val_enter_password), getString(android.R.string.ok), "", false, false);
            etPassword.requestFocus();
        } else {
            if (Utils.isOnline(LoginActivity.this, true)) {
                getServicesResponse();
            }
        }
    }


    /**
     * for get login service response
     */
    private void getServicesResponse() {
        final ProgressDialog mDialog = Utils.showProgressDialog(this, getString(R.string.please_wait), false);
        try {
            TypedInput in = new TypedByteArray(getString(R.string.wsHeader), generateRequestJson().getBytes("utf-8"));
            TemplateAplication.getmInstance().getmRetrofitInterface().loginService(in, new Callback<LoginService>() {
                @Override
                public void success(LoginService responceModel, Response arg1) {
                    mDialog.dismiss();

                    Log.d("", "Message:-" + responceModel.getSettings().getMessage());
                    Log.d("", "UserID:-" + responceModel.getLoginServiceResult().getUserID());
                    Log.d("", "Successfully login.");

                    if (responceModel.getSettings().getSuccess() == 1) {
                        if (responceModel.getLoginServiceResult().getUserID() != null) {

                            TemplateAplication.getmInstance().savePreferenceDataString(getString(R.string.userID), responceModel.getLoginServiceResult().getUserID());
                            TemplateAplication.getmInstance().savePreferenceDataBoolean(getString(R.string.IsLogin), true);

                            Intent mHomeIntent = new Intent(LoginActivity.this, HomeActivity.class);
                            startActivity(mHomeIntent);
                            overridePendingTransition(R.anim.anim_right_in, R.anim.anim_left_out);
                            finish();

                        } else {
                            Utils.displayDialog(LoginActivity.this, getString(R.string.app_name), responceModel.getSettings().getMessage(), getString(android.R.string.ok), "", false, false);
                        }
                    } else {
                        Utils.displayDialog(LoginActivity.this, getString(R.string.app_name), responceModel.getSettings().getMessage(), getString(android.R.string.ok), "", false, false);
                    }
                }

                @Override
                public void failure(RetrofitError retrofitError) {
                    mDialog.dismiss();
                    Utils.displayDialog(LoginActivity.this, getString(R.string.app_name), retrofitError.getMessage(), getString(android.R.string.ok), "", false, false);
                }
            });
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    /**
     * @return string object of requested json passed as input parameters
     */
    private String generateRequestJson() {
        final JSONObject jsonObject = new JSONObject();
        final JSONObject jsonObjectMain = new JSONObject();


        try {
            jsonObject.put(getString(R.string.params_email), etEmail.getText().toString().trim());
            jsonObject.put(getString(R.string.params_password), etPassword.getText().toString().trim());
            jsonObject.put(getString(R.string.params_deviceID), Utils.getDeviceID(this));
            jsonObject.put(getString(R.string.params_apiKey), "c686bc4e7fa22584ef6fa83c8b8d6");
            jsonObject.put(getString(R.string.params_notificationDeviceToken), "123");
            jsonObject.put(getString(R.string.params_notificationDeviceType), "1");

            Log.d("", "jsonObject Req:-" + jsonObject.toString());

            jsonObjectMain.put(getString(R.string.params_request), jsonObject);
            jsonObjectMain.put(getString(R.string.params_service), Constans.service_login);
            jsonObjectMain.put(getString(R.string.params_method), "POST");

            Log.d("", "jsonObjectMain Req:-" + jsonObjectMain.toString());

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return jsonObjectMain.toString();
    }


    @Override
    public void onClick(View v) {
        Utils.hideKeyboard(LoginActivity.this);

        switch (v.getId()) {
            case R.id.activity_login_btnLogin:
                validateFields();
                break;
            case R.id.activity_login_tvForgotPassword:
                Intent mHomeIntent = new Intent(LoginActivity.this, ForgotPasswordActivity.class);
                startActivity(mHomeIntent);
                overridePendingTransition(R.anim.anim_right_in, R.anim.anim_left_out);
                break;
            case R.id.activity_login_tvSignUp:
                Intent mHomeIntentSign = new Intent(LoginActivity.this, SignUpActivity.class);
                startActivity(mHomeIntentSign);
                overridePendingTransition(R.anim.anim_right_in, R.anim.anim_left_out);
                break;
            case R.id.activity_login_tvFblogin:
                loginFacebook();
                break;
           case R.id.activity_login_tvTwitterlogin:
               loginTwitter();
               break;
            case R.id.activity_login_tvGooglePluslogin:
                loginGooglePlus();
                break;
            case R.id.activity_login_tvLinkedInlogin:
                loginLinkedIn();
                break;
            default:
                break;
        }
    }
    private void loginLinkedIn()
    {
        ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);

        final LinkedinDialog d = new LinkedinDialog(LoginActivity.this,progressDialog);
        d.show();


        // set call back listener to get oauth_verifier value
        d.setVerifierListener(new LinkedinDialog.OnVerifyListener()
        {

            @Override
            public void onVerify(String verifier) {
                try {
                    Log.i("LinkedinSample", "verifier: " + verifier);

                    accessToken = LinkedinDialog.oAuthService
                            .getOAuthAccessToken(LinkedinDialog.liToken,
                                    verifier);



                    LinkedinDialog.factory.createLinkedInApiClient(accessToken);
                    client = factory.createLinkedInApiClient(accessToken);


                    client = factory.createLinkedInApiClient(accessToken);
                    client.postNetworkUpdate("LinkedIn Android app test");
                    // Person profile = client.getProfileForCurrentUser();
                    com.google.code.linkedinapi.schema.Person profile = null;
                    try {
                        profile = client.getProfileForCurrentUser(EnumSet.of(
                                ProfileField.ID, ProfileField.FIRST_NAME,
                                ProfileField.EMAIL_ADDRESS, ProfileField.LAST_NAME,
                                ProfileField.HEADLINE, ProfileField.INDUSTRY,
                                ProfileField.PICTURE_URL, ProfileField.DATE_OF_BIRTH,
                                ProfileField.LOCATION_NAME, ProfileField.MAIN_ADDRESS,
                                ProfileField.LOCATION_COUNTRY));

                        Person p = client.getProfileForCurrentUser();

                        Log.d("ID", "" + p.getId());
                        Log.d("Firstname", "" + p.getFirstName());
                        Log.d("Lastname", "" + p.getLastName());
                        Log.d("Email", "" + p.getEmailAddress());



                    } catch (NullPointerException e) {
                        // TODO: handle exception
                    }


                    d.dismiss();

                } catch (Exception e) {
                    Log.d("LinkedinSample", "error to get verifier");
                    e.printStackTrace();
                }
            }
        });

        // set progress dialog
        progressDialog.setMessage("Loading...");
        progressDialog.setCancelable(true);
        progressDialog.show();

    }

    private void loginGooglePlus()
    {
        //GooglePlusAPI.getInstance().disconnect();
        GooglePlusAPI.getInstance().getPersonInformation(Method.PROFILE, new GooglePlusInterface() {
            @Override
            public void getMyProfile(com.google.android.gms.plus.model.people.Person person)
            {


                Log.d("","Id:-"+person.getId());
                Log.d("","First Name:-"+person.getName());
                Log.d("","Last Name:-"+person.getNickname());
                Log.d("","Birthday:-"+person.getBirthday());
                Log.d("","FUll Name:-"+person.getDisplayName());


            }
        });
    }

    private void loginFacebook()
    {
        FacebookAPI.getInstance().facebookMeRequest(this, Method.PROFILE, new FacebookInterface()
        {
            @Override
            public void getMyProfile(JSONObject jsonObject)
            {
                try {
                    Log.d("","Id:-"+jsonObject.getString("id"));
                    Log.d("","First Name:-"+jsonObject.getString("first_name"));
                    Log.d("","Last Name:-"+jsonObject.getString("last_name"));
                    Log.d("","Email:-"+jsonObject.getString("email"));
                    Log.d("","FUll Name:-"+jsonObject.getString("name"));


                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });
    }

    private void loginTwitter()
    {

        twitterLogin = new TwitterLogin(this, CONSUMER_KEY, CONSUMER_SECRET, CALLBACK_URL);
        twitterLogin.checkLoginForTwitter(this, "test message for tweet", "");



    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (FacebookAPI.getInstance().getCallbackManager() != null) {
            FacebookAPI.getInstance().getCallbackManager().onActivityResult(requestCode, resultCode, data);
        }

        if (requestCode == GooglePlusAPI.SIGN_IN) {

            if (!GooglePlusAPI.getInstance().getGoogleApiClient().isConnecting()) {
                GooglePlusAPI.getInstance().getGoogleApiClient().reconnect();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        GooglePlusAPI.getInstance().disconnect();
        FacebookAPI.getInstance().logout();
    }

}
