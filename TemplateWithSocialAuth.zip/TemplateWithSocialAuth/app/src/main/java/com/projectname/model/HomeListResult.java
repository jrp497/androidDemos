package com.projectname.model;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class HomeListResult
{
	private String ServiceMsg;
	private List<HomeResponseList> ProjectResponseList = new ArrayList<HomeResponseList>();
	@SerializedName("system_status")
	private String systemStatus;

	/**
	 * @return The HomeResponseList
	 */
	public List<HomeResponseList> getProjectResponseList()
	{
		return ProjectResponseList;
	}

	/**
	 * @param ProjectResponseList
	 *            The HomeResponseList
	 */
	public void setProjectResponseList(List<HomeResponseList> ProjectResponseList)
	{
		this.ProjectResponseList = ProjectResponseList;
	}

	/**
	 * @return The systemStatus
	 */
	public String getSystemStatus()
	{
		return systemStatus;
	}

	/**
	 * @param systemStatus
	 *            The system_status
	 */
	public void setSystemStatus(String systemStatus)
	{
		this.systemStatus = systemStatus;
	}

	/**
	 * @return The ServiceMsg
	 */
	public String getServiceMsg()
	{
		return ServiceMsg;
	}

	/**
	 * @param ServiceMsg
	 *            The ServiceMsg
	 */
	public void setServiceMsg(String ServiceMsg)
	{
		this.ServiceMsg = ServiceMsg;
	}
}
