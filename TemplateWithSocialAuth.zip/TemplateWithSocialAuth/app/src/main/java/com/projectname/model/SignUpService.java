package com.projectname.model;

import com.google.gson.annotations.SerializedName;

public class SignUpService
{
	@SerializedName("settings")
	private Settings Settings;

	/**
	 * @return The Settings
	 */
	public  Settings getSettings()
	{
		return Settings;
	}

	/**
	 * @param settings
	 *
	 */
	public void setSettings(Settings settings) {
		Settings = settings;
	}

}
