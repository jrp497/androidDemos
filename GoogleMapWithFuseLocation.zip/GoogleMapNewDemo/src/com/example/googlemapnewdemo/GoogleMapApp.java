package com.example.googlemapnewdemo;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;

import android.app.Application;
import android.location.Location;
import android.os.Bundle;

public class GoogleMapApp extends Application implements LocationListener,
		GoogleApiClient.ConnectionCallbacks,
		GoogleApiClient.OnConnectionFailedListener {

	private LocationRequest locationRequest;
	private GoogleApiClient googleApiClient;

	private double lat;

	public double getLat() {
		return lat;
	}

	public double getLng() {
		return lng;
	}

	private double lng;

	@Override
	public void onCreate() {
		super.onCreate();
		locationWork();
	}

	private void locationWork() {
		locationRequest = new LocationRequest();
		locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
		locationRequest.setInterval(5000);

		googleApiClient = new GoogleApiClient.Builder(this)
				.addConnectionCallbacks(this)
				.addOnConnectionFailedListener(this)
				.addApi(LocationServices.API).build();

		googleApiClient.connect();
	}

	@Override
	public void onConnectionFailed(ConnectionResult arg0) {

	}

	@Override
	public void onConnected(Bundle arg0) {

		final Location location = LocationServices.FusedLocationApi
				.getLastLocation(googleApiClient);

		if (location != null) {
			lat = location.getLatitude();
			lng = location.getLongitude();
		}

		LocationServices.FusedLocationApi.requestLocationUpdates(
				googleApiClient, locationRequest, this);

	}

	@Override
	public void onConnectionSuspended(int arg0) {

	}

	@Override
	public void onLocationChanged(Location location) {
		if (location != null) {
			lat = location.getLatitude();
			lng = location.getLongitude();
		}
	}

	@Override
	public void onTerminate() {

		LocationServices.FusedLocationApi.removeLocationUpdates(
				googleApiClient, this);

		super.onTerminate();
	}

}
