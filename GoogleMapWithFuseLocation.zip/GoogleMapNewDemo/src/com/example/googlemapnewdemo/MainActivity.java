package com.example.googlemapnewdemo;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.GoogleMap.OnMapLoadedCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import android.support.v4.app.FragmentActivity;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

public class MainActivity extends FragmentActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		final SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
				.findFragmentById(R.id.map);

		final GoogleMap googleMap = mapFragment.getMap();
		GoogleMapApp googleMapApp = (GoogleMapApp) getApplicationContext();

		if (googleMap != null) {

			LatLng latLng = new LatLng(googleMapApp.getLat(),
					googleMapApp.getLng());

			googleMap.setMyLocationEnabled(true);
			googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));

			googleMap.addMarker(new MarkerOptions().title("Sydney")
					.snippet("The most populous city in Australia.")
					.position(latLng));

		} else {
			Toast.makeText(this, "Map is not available", Toast.LENGTH_LONG)
					.show();
		}

		Toast.makeText(this, "" + googleMapApp.getLat(), Toast.LENGTH_LONG)
				.show();

		Toast.makeText(this, "" + googleMapApp.getLng(), Toast.LENGTH_LONG)
				.show();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

}
