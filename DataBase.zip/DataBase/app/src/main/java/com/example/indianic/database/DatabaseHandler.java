package com.example.indianic.database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by indianic on 14/07/15.
 */
public class DatabaseHandler extends SQLiteOpenHelper {
    String CREATE_CONTACTS_TABLE = "CREATE TABLE " + TABLE_CONTACTS + "("
            + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT,"
            + KEY_ADD + " TEXT" + ")";


    public static final int DATABASE_VERSION=1; //database version

    public static final String DATABASE_NAME="contactsManager";//database name

    public static final String TABLE_CONTACTS="contacts";//contacts table

    //contacts table column name
    private static final String KEY_ID ="id";
    private static final String KEY_NAME="name";
    private static final String KEY_ADD="address";


    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
        Log.d("result", "db constructercall");
    }








    @Override
    public void onCreate(SQLiteDatabase db) {

        Log.e("querry",CREATE_CONTACTS_TABLE);

        db.execSQL(CREATE_CONTACTS_TABLE);
        Log.d("result", "db tables  create");


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.d("result", "db tables  upgrade");
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_CONTACTS);
        onCreate(db);

    }


    // CRUD Operations


    //adding new contact

    public void addContacts (contactsModel contacts){

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values =  new ContentValues();

        values.put(KEY_NAME,contacts.getName());// Contact Name
        values.put(KEY_ADD,contacts.getAdd());//contact Add

        //inserting row
        db.insert(TABLE_CONTACTS,null,values);
        db.close();//closing database

    }

    // getting single contact
    public  contactsModel getContacts (int id){

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.query(TABLE_CONTACTS,new String[]{KEY_ID,KEY_NAME,KEY_ADD},KEY_ID+"+?",new String[]{String.valueOf(id)},null,null,null,null);

        if (cursor != null){
            cursor.moveToFirst();
        }

        contactsModel contact = new contactsModel(Integer.parseInt(cursor.getString(0)),cursor.getString(1),cursor.getString(2));
        return contact;

    }




    // Deleting single contact
    public void deleteContact(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACTS, KEY_ID + " = ?",
                new String[] { String.valueOf(id) });
        db.close();
    }





}
