package com.example.indianic.database;

import android.app.Activity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;


public class MainActivity extends Activity {


    private TextView name, address, id;
    private Button submit, retrive,delete;
    private DatabaseHandler databaseHandler;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        databaseHandler=new DatabaseHandler(MainActivity.this);

        name = (TextView)findViewById(R.id.editTextName);
        address = (TextView)findViewById(R.id.editTextAddress);
        id= (TextView)findViewById(R.id.editTextId);

        submit =(Button)findViewById(R.id.buttonSubmit);
        retrive=(Button)findViewById(R.id.buttonRetrive);
        delete = (Button)findViewById(R.id.buttonDelete);






        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String n = name.getText().toString();
                final String a = address.getText().toString();

                if (a==""||n==""){



                }
                else{
                    contactsModel contacts = new contactsModel(n,a);
                    databaseHandler.addContacts(contacts);

                    Toast.makeText(MainActivity.this,"Entry Created in database",Toast.LENGTH_SHORT).show();

                }


            }
        });


        retrive.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int i = Integer.parseInt(id.getText().toString());



                contactsModel cn = databaseHandler.getContacts(i);

                String log = "ID: " + cn.getId() + "Name: " + cn.getName() + "Add: "+ cn.getAdd() ;

                Log.d("Entry: ",log);

            }
        });


        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final int i = Integer.parseInt(id.getText().toString());


                databaseHandler.deleteContact(i);


            }
        });


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
