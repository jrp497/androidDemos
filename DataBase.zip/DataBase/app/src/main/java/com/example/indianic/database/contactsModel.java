package com.example.indianic.database;

/**
 * Created by indianic on 14/07/15.
 */
public class contactsModel {

    private int id;
    private String name;
    private String add;

    public contactsModel(int id, String name, String add) {
        this.id = id;
        this.name = name;
        this.add = add;
    }
    public contactsModel( String name, String add) {

        this.name = name;
        this.add = add;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }
}
