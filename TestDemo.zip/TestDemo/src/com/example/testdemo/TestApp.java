package com.example.testdemo;

import java.util.ArrayList;

import android.app.Application;

public class TestApp extends Application {

	private ArrayList<String> arrayList;

	@Override
	public void onCreate() {
		super.onCreate();
		arrayList = new ArrayList<String>();

	}

	public ArrayList<String> getArrayList() {
		return arrayList;
	}

	public void setArrayList(ArrayList<String> arrayList) {
		this.arrayList = arrayList;
	}

}
