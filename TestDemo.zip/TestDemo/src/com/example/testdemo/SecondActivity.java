package com.example.testdemo;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class SecondActivity extends Activity implements OnClickListener,
		OnItemSelectedListener {

	private static final String TAG = SecondActivity.class.getSimpleName();

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		Log.e(TAG, "onCreate");
		final Button button = (Button) findViewById(R.id.button1);
		final Spinner spinner = (Spinner) findViewById(R.id.spinner);

		final ArrayList<TestModel> arrayList = new ArrayList<TestModel>();

		for (int i = 0; i < 5; i++) {
			final TestModel testModel = new TestModel();
			testModel.setId("" + i);
			testModel.setName("ILDC" + i);
			arrayList.add(testModel);
		}

		final ArrayList<String> arrayListSpinner = new ArrayList<String>();

		for (int i = 0; i < 5; i++) {
			arrayListSpinner.add("ILDC" + i);
		}

		final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				R.layout.row_spinner, R.id.textview, arrayListSpinner);

		spinner.setAdapter(adapter);
		spinner.setOnItemSelectedListener(this);

		// spinner.setOnItemSelectedListener(new OnItemSelectedListener() {
		//
		// @Override
		// public void onItemSelected(AdapterView<?> parent, View view,
		// int position, long id) {
		// // TODO Auto-generated method stub
		//
		// }
		//
		// @Override
		// public void onNothingSelected(AdapterView<?> parent) {
		// // TODO Auto-generated method stub
		//
		// }
		// });

		button.setOnClickListener(this);
		// button.setOnClickListener(new OnClickListener() {
		//
		// @Override
		// public void onClick(View v) {
		// // TODO Auto-generated method stub
		// Toast.makeText(SecondActivity.this, "button", Toast.LENGTH_LONG)
		// .show();
		// }
		// });
	}

	// public void onClickFromXml(View view) {
	// Toast.makeText(SecondActivity.this, "onClickFromXml", Toast.LENGTH_LONG)
	// .show();
	// }

	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		Log.e(TAG, "onStart");
	}

	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		Log.e(TAG, "onStop");
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
		Log.e(TAG, "onPause");
	}

	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		Log.e(TAG, "onResume");
	}

	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();
		Log.e(TAG, "onDestroy");
	}

	@Override
	protected void onRestart() {
		// TODO Auto-generated method stub
		super.onRestart();
		Log.e(TAG, "onRestart");
	}

	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button1:
			final Intent intent = new Intent(this, MainActivity.class);
			startActivityForResult(intent, 0);

			break;

		}
	}

	@Override
	public void onItemSelected(AdapterView<?> parent, View view, int position,
			long id) {

		if (parent.getId() == R.id.spinner) {
			Toast.makeText(SecondActivity.this,
					"spinner" + parent.getSelectedItem().toString(),
					Toast.LENGTH_LONG).show();
		}
	}

	@Override
	public void onNothingSelected(AdapterView<?> parent) {
		// TODO Auto-generated method stub

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		if (resultCode == Activity.RESULT_OK) {
			if (requestCode == 0) {
				if (data != null && data.getExtras() != null) {
					Toast.makeText(SecondActivity.this,
							"spinner" + data.getStringExtra("key_data"),
							Toast.LENGTH_LONG).show();
				}
			}
		}
	}

}
