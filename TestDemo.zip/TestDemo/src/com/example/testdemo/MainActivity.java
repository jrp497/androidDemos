package com.example.testdemo;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends ActionBarActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// final TreeSet<String> al = new TreeSet<String>();
		// al.add("ravi");
		// al.add("Vijay");
		// al.add("Ravi");
		// al.add("Ajay");
		//
		// final Iterator<String> itr = al.iterator();
		// while (itr.hasNext()) {
		// System.out.println(itr.next());
		// }

		if (getIntent() != null && getIntent().getExtras() != null) {
			final String name = getIntent().getStringExtra("key_name");
			Toast.makeText(this, name, Toast.LENGTH_LONG).show();
		}

		final Button button = (Button) findViewById(R.id.button1);
		final EditText editTextEnable = (EditText) findViewById(R.id.edittext_enable);
		final EditText editTextf = (EditText) findViewById(R.id.edittext_focusable);

		final TestApp testApp = (TestApp) getApplicationContext();

		final StringBuilder builder = new StringBuilder("");
		for (int i = 0; i < testApp.getArrayList().size(); i++) {
			final String str = testApp.getArrayList().get(i);
			builder.append(" " + str);
		}
		editTextf.setText(builder.toString());
		editTextEnable.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(MainActivity.this, "E", Toast.LENGTH_LONG)
						.show();
			}
		});

		editTextf.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Toast.makeText(MainActivity.this, "F", Toast.LENGTH_LONG)
						.show();
			}
		});

		button.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				final Intent intent = new Intent();
				intent.putExtra("key_data", "Mavya");
				setResult(Activity.RESULT_CANCELED, intent);
				finish();

			}
		});

	}

	public void onClickVisiable(final View view) {
		Toast.makeText(MainActivity.this, "Visible", Toast.LENGTH_LONG).show();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
