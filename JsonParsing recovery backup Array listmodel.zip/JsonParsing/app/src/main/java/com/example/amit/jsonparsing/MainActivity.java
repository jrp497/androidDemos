package com.example.amit.jsonparsing;

import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

public class MainActivity extends Activity {

    private ProgressDialog pDialog;
    private Context context;

    /**
     * **************************************  fix  ****************************************
     */
    private ListView listView;
    private ArrayList<ListModel> arrayList;
    private ListModel listModel;
    CustomBaseAdapter adapter;
    /**
     * **************************************  fix  ****************************************
     */

    // URL to get contacts JSON
    private static String url = "http://mbdbtechnology.com/projects/officeapp/ws/webservice/company_list";


    // JSON Node names
    private static final String TAG_ALL_DATA = "all_data";
    private static final String TAG_COMPANY_ID = "company_id";
    private static final String TAG_COMPANY_NAME = "company_name";
    private static final String TAG_COMPANY_LOGO = "company_logo";

    // contacts JSONArray
    JSONArray contacts = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = this;

        arrayList = new ArrayList<ListModel>();

        // Calling async task to get json
        new GetContacts().execute();
    }

    /**
     * Async task class to get json by making HTTP call
     */
    private class GetContacts extends AsyncTask<Void, Void, Void> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            // Showing progress dialog
            pDialog = new ProgressDialog(MainActivity.this);
            pDialog.setMessage("Please wait...");
            pDialog.setCancelable(false);
            pDialog.show();

        }

        @Override
        protected Void doInBackground(Void... arg0) {
            // Creating service handler class instance
            ServiceHandler sh = new ServiceHandler();

            // Making a request to url and getting response
            String jsonStr = sh.makeServiceCall(url, ServiceHandler.GET);

            Log.d("Response: ", "> " + jsonStr);

            if (jsonStr != null) {
                try {
                    JSONObject jsonObj = new JSONObject(jsonStr);

                    // Getting JSON Array node
                    contacts = jsonObj.getJSONArray(TAG_ALL_DATA);

                    // looping through All Contacts
                    for (int i = 0; i < contacts.length(); i++) {
                        JSONObject c = contacts.getJSONObject(i);

                        String company_id = c.getString(TAG_COMPANY_ID);
                        String company_name = c.getString(TAG_COMPANY_NAME);
                        String company_logo = c.getString(TAG_COMPANY_LOGO);

                        // Phone node is JSON Object

                        // tmp hashmap for single contact
                        ListModel list = new ListModel();

                        list.setStringcompany_id(company_id);
                        list.setStringcompany_name(company_name);
                        list.setBitmapcompany_logo(company_logo);

                        arrayList.add(list);

                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            } else {
                Log.e("ServiceHandler", "Couldn't get any data from the url");
            }

            return null;
        }


        @Override
        protected void onPostExecute(Void result) {
            super.onPostExecute(result);
            // Dismiss the progress dialog
            if (pDialog.isShowing())
                pDialog.dismiss();

            /**
             * Updating parsed JSON data into ListView
             * */

            /*****************************************  fix  *****************************************/
            listView = (ListView) findViewById(R.id.activity_main_list);
            listModel = new ListModel();
            adapter = new CustomBaseAdapter(MainActivity.this, arrayList);
            listView.setAdapter(adapter);

/*****************************************  fix  *****************************************/
        }
    }
}