package com.example.amit.jsonparsing;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

/**
 * Created by Amit on 20-07-2015.
 */

public class CustomBaseAdapter extends BaseAdapter {

    private LayoutInflater inflater;
    private ArrayList<ListModel> arrayList;
    private Context context;
    private ListModel listModel;

    private MainActivity activity;

    public CustomBaseAdapter(final Context context, final ArrayList<ListModel> arrayList) {
        this.arrayList = arrayList;
        inflater = ((Activity) context).getLayoutInflater();
        this.context = context;
        activity = (MainActivity) context;
    }

    @Override
    public int getCount() {
        return arrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder holder;

        if (convertView == null) {

            holder = new ViewHolder();

            convertView = inflater.inflate(R.layout.list_item, null);

            holder.textViewCOMPANY_ID = (TextView) convertView.findViewById(R.id.id);
            holder.textViewCOMPANY_NAME = (TextView) convertView.findViewById(R.id.name);
            holder.imageViewCOMPANY_LOGO = (ImageView) convertView.findViewById(R.id.logo);
            convertView.setTag(holder);

        } else {

            holder = (ViewHolder) convertView.getTag();
        }

        listModel = arrayList.get(position);

        holder.textViewCOMPANY_ID.setText(listModel.getStringcompany_id());
        holder.textViewCOMPANY_NAME.setText(listModel.getStringcompany_name());
        Picasso.with(context).load(listModel.getBitmapcompany_logo()).placeholder(R.mipmap.ic_launcher).error(R.mipmap.ic_launcher).into(holder.imageViewCOMPANY_LOGO);

        return convertView;
    }

    private class ViewHolder {

        private TextView textViewCOMPANY_ID;
        private TextView textViewCOMPANY_NAME;
        private ImageView imageViewCOMPANY_LOGO;
    }
}