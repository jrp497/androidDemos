package com.example.hp.retrofitexample;

import retrofit.Callback;
import retrofit.http.GET;
import retrofit.http.Query;
 
public interface IApiMethods {
 
//    @GET("/get/curators.json")
//    Curator getCurators(
//            @Query("api_key") String key
//    );


//    @GET("/get/curators.json")
//    Curator getCurators(
//            @Query("api_key") String key
//    );






    @GET("/get/curators.json")
    void getCurators(
            @Query("api_key") String key, Callback<Curator> cb
    );
}