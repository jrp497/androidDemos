/*
 * Copyright (c) 2015. $user
 */

package indianic.com.facebookdemo;

import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.util.Log;
import android.widget.Toast;

/**
 * @author Ahesanali Khanusiya
 *         <p/>
 *         For displaying messages in logcat
 *         For displaying Dialog in common way.
 */
public final class Logger {

    private static final String TAG = "Logger";

    /**
     * Log.e()
     *
     * @param message which is display in logcat.
     */
    public static final void e(String message) {
        Log.e(Logger.TAG, message);
    }

    /**
     * Log.v()
     *
     * @param message which is display in logcat.
     */
    public static final void v(String message) {
        Log.v(Logger.TAG, message);
    }

    /**
     * Log.w()
     *
     * @param message which is display in logcat.
     */
    public static final void w(String message) {
        Log.w(Logger.TAG, message);
    }

    /**
     * Log.d()
     *
     * @param message which is display in logcat.
     */
    public static final void d(String message) {
        Log.d(Logger.TAG, message);
    }

    /**
     * Log.i()
     *
     * @param message which is display in logcat.
     */
    public static final void i(String message) {
        Log.i(Logger.TAG, message);
    }


    /**
     * Show Default Toast
     *
     * @param context Application/Activity context
     * @param message Message which is display in toast.
     */
    public static final void toast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }

    /**
     * Show Default dialog.
     *
     * @param context Application/Activity Context for creating dialog.
     * @param title   Title of dialog
     * @param message Message of dialog
     */
    public static final void dialog(Context context, String title, String message) {

        Builder builder = new Builder(context);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setNeutralButton(context.getString(android.R.string.ok), new OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        builder.create().show();
    }


}
