package indianic.com.facebookdemo;

import org.json.JSONObject;

/**
 * Created by Ahesanali Khanusiya on 20/4/15.
 */

/**
 * Used for getting user profile detail using GraphRequest
 */
public interface FacebookInterface {
    /**
     *
     * @param jsonObject All profile detail which is provided by facebook default.
     */
    void getMyProfile(JSONObject jsonObject);
}
