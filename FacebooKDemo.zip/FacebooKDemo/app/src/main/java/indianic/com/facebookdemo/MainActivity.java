package indianic.com.facebookdemo;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.share.ShareApi;
import com.facebook.share.Sharer;
import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.model.SharePhoto;
import com.facebook.share.model.SharePhotoContent;
import com.facebook.share.widget.ShareDialog;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class MainActivity extends Activity {

    private static ArrayList<String> PERMISSIONS;
    private String field = "id,name,first_name,last_name,email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        PERMISSIONS = new ArrayList<String>();
        PERMISSIONS.add("public_profile");
        PERMISSIONS.add("email");
//        PERMISSIONS.add("publish_actions");

        new FacebookAPI();
        FacebookAPI.getInstance().init(this);
        FacebookAPI.getInstance().setPermissions(PERMISSIONS);
        FacebookAPI.getInstance().setField(field);
        Button login = (Button)findViewById(R.id.login);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginFacebook();
            }
        });

    }

    private void publishImage(){
        Bitmap image = BitmapFactory.decodeResource(getResources(), R.mipmap.ic_launcher);

        SharePhoto photo = new SharePhoto.Builder()
                .setBitmap(image)
                .setCaption("Welcome To Facebook Photo Sharing on steroids!")
                .build();

        SharePhotoContent content = new SharePhotoContent.Builder()
                .addPhoto(photo)
                .build();

        ShareDialog dialog = new ShareDialog(this);
        dialog.show(content);
//        ShareApi.share(content, new FacebookCallback<Sharer.Result>() {
//            @Override
//            public void onSuccess(Sharer.Result result) {
//                Log.e("Share","Success");
//            }
//
//            @Override
//            public void onCancel() {
//                Log.e("Share","Cancel");
//            }
//
//            @Override
//            public void onError(FacebookException e) {
//                Log.e("Share",e.getCause().toString());
//            }
//        });

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    private void loginFacebook()
    {
        FacebookAPI.getInstance().facebookMeRequest(this, Method.PROFILE, new FacebookInterface()
        {
            @Override
            public void getMyProfile(JSONObject jsonObject)
            {
                try {
                    Log.d("",jsonObject.toString());
                    Log.d("","Id:-"+jsonObject.getString("id"));
                    Log.d("","FUll Name:-"+jsonObject.getString("name"));
                    publishImage();
//                    Log.d("","First Name:-"+jsonObject.getString("first_name"));
//                    Log.d("","Last Name:-"+jsonObject.getString("last_name"));
//                    Log.d("","Email:-"+jsonObject.getString("email"));



                } catch (JSONException e) {
                    e.printStackTrace();
                }


            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (FacebookAPI.getInstance().getCallbackManager() != null) {
            Log.d("","Success");
            FacebookAPI.getInstance().getCallbackManager().onActivityResult(requestCode, resultCode, data);
        }

    }

}
