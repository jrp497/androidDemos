package com.example.indianic.notificationexample;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by indianic on 22/07/15.
 */
public class ActivityTwo extends Activity {

        @Override
        public void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState);
            setContentView(R.layout.notification_layout);
        }
    }


