package com.example.dell.paypal_mpl_demo;

/**
 * Created by Dell on 4/7/2015.
 */
public class Util {

    public  static  final  String sand_box_id="APP-80W284485P519543T";
    public  static  final  String paypal_liv_id="APP-0C165959RL117014F";
    //public  static  final  String paypal_sdk_id="AZLO_x33AwUGmMcL354-ufTI7G-aUy0UXJXpE8n430XeWYjb13nvv0CKjcg8o89Agyt_C3Ef8j2tC9so";
    public  static  final  String paypal_sdk_id="AYAK7CwNCe0AIz18s4UUdDmnvQWiqImUASFmYMqVnuzkXI-wIVEbdnP22JZoO4zgD8ot5ZSk_s1xfVjY";
}
