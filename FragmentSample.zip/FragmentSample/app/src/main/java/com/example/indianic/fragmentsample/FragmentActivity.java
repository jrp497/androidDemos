package com.example.indianic.fragmentsample;

import android.app.Fragment;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

/**
 * Created by indianic on 09/07/15.
 */
public class FragmentActivity extends Fragment {

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        final View view = inflater.inflate(R.layout.framelayout_one,null);

        initialize(view);

        return view;
    }

    private void initialize(final View view){

                final Button button =(Button)view.findViewById(R.id.buttonFragment1);

                button.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        final  SecondFragmentActivity secondfragment = new SecondFragmentActivity();
                        final Bundle bundle = new Bundle();
                        bundle.putString("key","jay");
                        secondfragment.setArguments(bundle);

                        ((MainActivity) getActivity()).addFragment(FragmentActivity.this,
                               secondfragment);
                    }
                });
    }
}